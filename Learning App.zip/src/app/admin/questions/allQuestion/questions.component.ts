import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfirmDialogComponent } from '../../../../shared/components/confirmation_Dialog/confirm-dialog.component';
import { MatDialog, MatDialogModule } from '@angular/material/dialog'
import { DevExtremeModule } from 'devextreme-angular';;
import { UpdateDialogComponent } from '../../../../shared/components/worker_Dialog/worker-dialog.component';
import { questions } from '../../../../data/question';
import { FormsModule } from '@angular/forms';  // Import FormsModule
import { QuestionFormComponent } from '../questionDialog/question-dialog.component';
import { createStore } from 'devextreme-aspnet-data-nojquery';
import 'devextreme/data/odata/store';

@Component({
  selector: 'app-questions',
  standalone: true,
  imports: [CommonModule, MatDialogModule, DevExtremeModule, QuestionFormComponent , ConfirmDialogComponent , UpdateDialogComponent ,FormsModule],
  templateUrl: './questions.component.html',
  styleUrl: './questions.component.scss'
})
export class QuestionsComponent {
  showTableView = false; 
  items = questions;
  filteredItems = this.items;
  remoteDataSource: any;
  searchQuery: string = '';

  setListView(): void {this.showTableView = false;}
  setTableView(): void { this.showTableView = true;}

  constructor(public dialog: MatDialog) {
    this.remoteDataSource = createStore({
      key: 'Id',
      loadUrl: 'https://localhost:7135/dxdatagrid'
    });
  }
  
  onDetailsClick(){

  }

  openUpdateDialog(item: any): void {
 
    const dialogRef = this.dialog.open(QuestionFormComponent, {
      data: { ...item }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log({result});
        const index = this.items.findIndex(i => i.id === result.id);
        if (index !== -1) {
          this.items[index] = result;
          console.log('Item updated:', result);
        }
      }
    });
  }
  openDeleteDialog(): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent);
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log('Item deleted');
      } else {
        console.log('Deletion canceled');
      }
    });
  }
  filterItems(): void {
    const query = this.searchQuery.toLowerCase();
    this.filteredItems = this.items.filter(item =>
      item.category.toLowerCase().includes(query)
    );
    console.log("this.filteredItems ====== ",this.filteredItems);
  }
}
