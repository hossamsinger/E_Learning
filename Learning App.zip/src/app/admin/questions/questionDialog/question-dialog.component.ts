import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';  // Import FormsModule here
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatRadioModule } from '@angular/material/radio'; 
import { MatCheckboxModule } from '@angular/material/checkbox'; 
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-question-form',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,  // Include FormsModule for ngModel
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatRadioModule,
    MatCheckboxModule,
  ],
  templateUrl: './question-dialog.component.html',
  styleUrls: ['./question-dialog.component.scss']
})
export class QuestionFormComponent {
  constructor( private snackBar: MatSnackBar) {}
  question: any = {
    questionId: '',
    questionName: '',
    questionType: '',
    questionLevel: '',
    questionMarks: '',
    questionChoices: ['', ''], // Start with two choices
    AnswerType : '',
    CorrectAnswer: '',
    
  };

  choiceType: string = 'multiChoices'; 
  updateCorrectAnswer(choice: string) {
    debugger;
    this.question.CorrectAnswer = choice;
  }
  updateAnswerType(choice: string) {
    this.question.AnswerType = choice;
  }

  submitForm() {
    console.log("Submited Data = " , this.question);
    
    this.clearForm();
    this.snackBar.open('Question Added Successfully...', '', {
      duration: 2000,
      panelClass: ['success-snackbar'], 
      horizontalPosition: 'right', 
      verticalPosition: 'top', 
    });
    // setTimeout(() => {
    //   location.reload();
    // }, 2000);
  }
  close(){
    
  }
  addChoice() {
    this.question.questionChoices.push('');
  }
  
  updateQuestionLevel() {
    if (this.question.questionLevel < 0) {
      this.question.questionLevel = 0;
    } else if (this.question.questionLevel > 5) {
      this.question.questionLevel = 5;
    }
  }
  
  clearForm() {
    this.question = {
      questionId: '',
      questionName: '',
      questionType: '',
      questionLevel: '',  
      questionMarks: '',
      questionChoices: ['', ''],
      CorrectAnswer: ''
    };
  }
}
