import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { CategoryDialogComponent } from '../categoryDialog/category-dialog.component';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatDialogModule } from '@angular/material/dialog';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ConfirmDialogComponent } from '../../../../shared/components/confirmation_Dialog/confirm-dialog.component';

@Component({
  selector: 'app-allCategory',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatDialogModule,
    MatButtonModule,
    MatInputModule,
    CategoryDialogComponent,
  ],
  templateUrl: './allCategory.component.html',
  styleUrls: ['./allCategory.component.scss'],
})
export class AllCategoryComponent {
  categories = [
    { category_id: 1, category_name: 'Electronics' },
    { category_id: 2, category_name: 'Furniture' },
    { category_id: 3, category_name: 'Clothing' },
    { category_id: 4, category_name: 'Books' },
    { category_id: 5, category_name: 'Toys' },
    { category_id: 6, category_name: 'Sports' },
    { category_id: 7, category_name: 'Home Appliances' },
    { category_id: 8, category_name: 'Beauty & Personal Care' },
    { category_id: 9, category_name: 'Automotive' },
    { category_id: 10, category_name: 'Health & Wellness' },
    { category_id: 11, category_name: 'Music' },
    { category_id: 12, category_name: 'Grocery' },
    { category_id: 13, category_name: 'Pet Supplies' },
    { category_id: 14, category_name: 'Stationery' },
    { category_id: 15, category_name: 'Garden & Outdoors' },
  ];

  constructor(private router: Router, private dialog: MatDialog) {}

  openDialog(categoryId?: number, categoryName?: string): void {
    const dialogRef = this.dialog.open(CategoryDialogComponent, {
      width: '400px',
      data: { categoryId: categoryId, categoryName: categoryName || '' },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        console.log('Dialog result:', result);
      }
    });
  }
  openDeleteDialog(): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent);

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        console.log('Item deleted');
        // Call your delete function here
      } else {
        console.log('Deletion canceled');
      }
    });
  }
}
