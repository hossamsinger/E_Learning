import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';

@Component({
  selector: 'app-category-dialog',
  standalone: true,
  imports: [
    MatFormFieldModule,
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatInputModule,
    FormsModule,
  ],
  templateUrl: './category-dialog.component.html',
  styleUrls: ['./category-dialog.component.scss'],
})
export class CategoryDialogComponent {
  constructor(
    @Inject(MAT_DIALOG_DATA)
    public data: { categoryId: number; categoryName: string },
    private dialogRef: MatDialogRef<CategoryDialogComponent>
  ) {}

  close(): void {
    this.dialogRef.close();
  }

  save(updateForm: any): void {
    if (!updateForm.valid) {
      alert('Please fill out all required fields!');
      return;
    }
    // if (isNaN(this.data.categoryId) || this.data.categoryId <= 0) {
    //   alert('Please Enter A valid Input for Category Id!');
    //   return;
    // }
    this.dialogRef.close(this.data);
  }
}
