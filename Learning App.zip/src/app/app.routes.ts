import { QuestionsComponent } from './admin/questions/allQuestion/questions.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { Routes } from '@angular/router';
import { ExamComponent } from './exam/exam.component';
import { ResultsComponent } from './results/results.component';
import { CreationExamComponent } from './creationExam/creationExam.component';
// import { QuestionComponent } from './admin/question/question.component';
import { AllCategoryComponent } from './admin/category/allCategory/allCategory.component';
export const routes: Routes = [  
  
  // =================================================
  //  Defult Routes For App.
  // =================================================
  { path: '', redirectTo: 'login', pathMatch: 'full' }, // Redirect to login


  // =================================================
  //  Routes For All Feature Of Admin And Component.
  // =================================================

  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'exam', component: ExamComponent },
  // { path: 'question', component: QuestionsComponent },
  { path: 'creationExam', component:CreationExamComponent  },
  { path: 'results', component: ResultsComponent },

  // =================================================
  //  Routes For All Feature Of Admin And Component.
  // =================================================

  { path: 'admin/AllCategory', component: AllCategoryComponent },
  // { path: 'admin/NewCategory', component:  },
  // { path: 'admin/Question', component: QuestionComponent },
  { path: 'admin/Questions', component: QuestionsComponent },
  // { path: 'admin/Exam', component: QuestionComponent },
  // { path: 'admin/Employee', component: QuestionComponent },



  // =================================================
  //  Routes For All UnLinked Routes.
  // =================================================

  { path: '**', redirectTo: 'login' }, // Wildcard route for undefined paths

  
];
