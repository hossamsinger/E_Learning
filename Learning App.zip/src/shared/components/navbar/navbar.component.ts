import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterModule} from '@angular/router';
import { CommonModule } from '@angular/common';
import {MatSelectModule} from '@angular/material/select';
import {MatFormFieldModule} from '@angular/material/form-field';
import { MatMenuModule } from '@angular/material/menu';
interface NavItem {
  label: string;
  path: string;
  badge?: number;
  role ?:string;
  submenu?: boolean;  
}
interface SubMenuItem {
  label: string;
  path: string; 
  badge?: number;
}

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive ,RouterModule  ,  MatMenuModule,MatFormFieldModule , MatSelectModule ]
})
export class NavbarComponent {
  navItems: NavItem[] = [
 // Admin menu item with submenu
    { label: 'Admin',          path: '',                badge: 2,       role: 'admin'    , submenu: true },
    { label: 'Dashboard',      path: '/dashboard',      badge: 5,       role:"*"         , submenu: false },
    { label: 'Exam Creation ', path: '/creationExam',   badge: 7,       role:"admin"     , submenu: false },
    { label: 'Exam Starting',  path: '/exam' ,          badge: 50,      role:"*"         , submenu: false },
    // { label: 'All Question',   path: '/question',       badge: 50,      role:"admin"     , submenu: false },
    { label: 'Results',        path: '/results',        badge: 12,      role:"admin"     , submenu: false },
  ];  
  adminMenuItems: SubMenuItem[] = [
    // { label: 'NewCategories', path: '/admin/NewCategory'  },
    { label: 'Categories', path: '/admin/AllCategory'  },
    { label: 'Questions', path: '/admin/Questions' },
    { label: 'Exams', path: '/admin/Exam' },
    { label: 'Employees', path: '/admin/Employee' },
  ];
item: any;
}