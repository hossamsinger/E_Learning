import {
  DxDataGridComponent,
  DxDataGridModule
} from "./chunk-O3U5QLHW.js";
import "./chunk-XAE2T6JP.js";
import "./chunk-VVVI3OU6.js";
import "./chunk-KKWCXJXC.js";
import "./chunk-H6LXBMNC.js";
import "./chunk-3N2Q5ACA.js";
import "./chunk-TEJ7FDOJ.js";
import "./chunk-ND5ICVCX.js";
import "./chunk-WBCLGCHV.js";
import "./chunk-EBLT4CH3.js";
import "./chunk-74ZAWBSC.js";
import "./chunk-WOR4A3D2.js";
export {
  DxDataGridComponent,
  DxDataGridModule
};
//# sourceMappingURL=devextreme-angular_ui_data-grid.js.map
