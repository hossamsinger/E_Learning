import {
  init_renderer,
  renderer_default
} from "./chunk-KKWCXJXC.js";
import {
  XHR_ERROR_UNLOAD,
  abstract_store_default,
  array_query_default,
  errorMessageFromXhr,
  errors,
  init_abstract_store,
  init_array_query,
  init_errors,
  init_store_helper,
  init_utils,
  keysEqual,
  rejectedPromise,
  store_helper_default,
  trivialPromise
} from "./chunk-3N2Q5ACA.js";
import {
  Deferred,
  _extends,
  deepExtendArraySafe,
  fromPromise,
  guid_default,
  init_data,
  init_deferred,
  init_extends,
  init_guid,
  init_object,
  when
} from "./chunk-TEJ7FDOJ.js";
import {
  config_default,
  extend,
  init_config,
  init_extend,
  init_type,
  isDefined,
  isEmptyObject,
  isFunction,
  isObject,
  isPlainObject
} from "./chunk-ND5ICVCX.js";
import {
  __esm,
  __export
} from "./chunk-WOR4A3D2.js";

// node_modules/devextreme/esm/data/array_utils.js
function hasKey(target, keyOrKeys) {
  let key;
  const keys = "string" === typeof keyOrKeys ? keyOrKeys.split() : keyOrKeys.slice();
  while (keys.length) {
    key = keys.shift();
    if (key in target) {
      return true;
    }
  }
  return false;
}
function findItems(keyInfo, items, key, groupCount) {
  let childItems;
  let result;
  if (groupCount) {
    for (let i = 0; i < items.length; i++) {
      childItems = items[i].items || items[i].collapsedItems || [];
      result = findItems(keyInfo, childItems || [], key, groupCount - 1);
      if (result) {
        return result;
      }
    }
  } else if (indexByKey(keyInfo, items, key) >= 0) {
    return items;
  }
}
function getItems(keyInfo, items, key, groupCount) {
  if (groupCount) {
    return findItems(keyInfo, items, key, groupCount) || [];
  }
  return items;
}
function generateDataByKeyMap(keyInfo, array) {
  if (keyInfo.key() && (!array._dataByKeyMap || array._dataByKeyMapLength !== array.length)) {
    const dataByKeyMap = {};
    const arrayLength = array.length;
    for (let i = 0; i < arrayLength; i++) {
      dataByKeyMap[JSON.stringify(keyInfo.keyOf(array[i]))] = array[i];
    }
    array._dataByKeyMap = dataByKeyMap;
    array._dataByKeyMapLength = arrayLength;
  }
}
function getCacheValue(array, key) {
  if (array._dataByKeyMap) {
    return array._dataByKeyMap[JSON.stringify(key)];
  }
}
function getHasKeyCacheValue(array, key) {
  if (array._dataByKeyMap) {
    return array._dataByKeyMap[JSON.stringify(key)];
  }
  return true;
}
function setDataByKeyMapValue(array, key, data) {
  if (array._dataByKeyMap) {
    array._dataByKeyMap[JSON.stringify(key)] = data;
    array._dataByKeyMapLength += data ? 1 : -1;
  }
}
function cloneInstanceWithChangedPaths(instance, changes, clonedInstances) {
  clonedInstances = clonedInstances || /* @__PURE__ */ new WeakMap();
  const result = instance ? Object.create(Object.getPrototypeOf(instance)) : {};
  if (instance) {
    clonedInstances.set(instance, result);
  }
  const instanceWithoutPrototype = _extends({}, instance);
  deepExtendArraySafe(result, instanceWithoutPrototype, true, true);
  for (const name in instanceWithoutPrototype) {
    const value = instanceWithoutPrototype[name];
    const change = null === changes || void 0 === changes ? void 0 : changes[name];
    if (isObject(value) && !isPlainObject(value) && isObject(change) && !clonedInstances.has(value)) {
      result[name] = cloneInstanceWithChangedPaths(value, change, clonedInstances);
    }
  }
  for (const name in result) {
    const prop = result[name];
    if (isObject(prop) && clonedInstances.has(prop)) {
      result[name] = clonedInstances.get(prop);
    }
  }
  return result;
}
function createObjectWithChanges(target, changes) {
  const result = cloneInstanceWithChangedPaths(target, changes);
  return deepExtendArraySafe(result, changes, true, true);
}
function applyBatch(_ref) {
  let {
    keyInfo,
    data,
    changes,
    groupCount,
    useInsertIndex,
    immutable,
    disableCache,
    logError,
    skipCopying
  } = _ref;
  const resultItems = true === immutable ? [...data] : data;
  changes.forEach((item) => {
    const items = "insert" === item.type ? resultItems : getItems(keyInfo, resultItems, item.key, groupCount);
    !disableCache && generateDataByKeyMap(keyInfo, items);
    switch (item.type) {
      case "update":
        update(keyInfo, items, item.key, item.data, true, immutable, logError);
        break;
      case "insert":
        insert(keyInfo, items, item.data, useInsertIndex && isDefined(item.index) ? item.index : -1, true, logError, skipCopying);
        break;
      case "remove":
        remove(keyInfo, items, item.key, true, logError);
    }
  });
  return resultItems;
}
function getErrorResult(isBatch, logError, errorCode) {
  return !isBatch ? rejectedPromise(errors.Error(errorCode)) : logError && errors.log(errorCode);
}
function update(keyInfo, array, key, data, isBatch, immutable, logError) {
  let target;
  const keyExpr = keyInfo.key();
  if (keyExpr) {
    if (hasKey(data, keyExpr) && !keysEqual(keyExpr, key, keyInfo.keyOf(data))) {
      return getErrorResult(isBatch, logError, "E4017");
    }
    target = getCacheValue(array, key);
    if (!target) {
      const index = indexByKey(keyInfo, array, key);
      if (index < 0) {
        return getErrorResult(isBatch, logError, "E4009");
      }
      target = array[index];
      if (true === immutable && isDefined(target)) {
        const newTarget = createObjectWithChanges(target, data);
        array[index] = newTarget;
        return !isBatch && trivialPromise(newTarget, key);
      }
    }
  } else {
    target = key;
  }
  deepExtendArraySafe(target, data, true);
  if (!isBatch) {
    if (config_default().useLegacyStoreResult) {
      return trivialPromise(key, data);
    } else {
      return trivialPromise(target, key);
    }
  }
}
function insert(keyInfo, array, data, index, isBatch, logError, skipCopying) {
  let keyValue;
  const keyExpr = keyInfo.key();
  const obj = isPlainObject(data) && !skipCopying ? extend({}, data) : data;
  if (keyExpr) {
    keyValue = keyInfo.keyOf(obj);
    if (void 0 === keyValue || "object" === typeof keyValue && isEmptyObject(keyValue)) {
      if (Array.isArray(keyExpr)) {
        throw errors.Error("E4007");
      }
      keyValue = obj[keyExpr] = String(new guid_default());
    } else if (void 0 !== array[indexByKey(keyInfo, array, keyValue)]) {
      return getErrorResult(isBatch, logError, "E4008");
    }
  } else {
    keyValue = obj;
  }
  if (index >= 0) {
    array.splice(index, 0, obj);
  } else {
    array.push(obj);
  }
  setDataByKeyMapValue(array, keyValue, obj);
  if (!isBatch) {
    return trivialPromise(config_default().useLegacyStoreResult ? data : obj, keyValue);
  }
}
function remove(keyInfo, array, key, isBatch, logError) {
  const index = indexByKey(keyInfo, array, key);
  if (index > -1) {
    array.splice(index, 1);
    setDataByKeyMapValue(array, key, null);
  }
  if (!isBatch) {
    return trivialPromise(key);
  } else if (index < 0) {
    return getErrorResult(isBatch, logError, "E4009");
  }
}
function indexByKey(keyInfo, array, key) {
  const keyExpr = keyInfo.key();
  if (!getHasKeyCacheValue(array, key)) {
    return -1;
  }
  for (let i = 0, arrayLength = array.length; i < arrayLength; i++) {
    if (keysEqual(keyExpr, keyInfo.keyOf(array[i]), key)) {
      return i;
    }
  }
  return -1;
}
var init_array_utils = __esm({
  "node_modules/devextreme/esm/data/array_utils.js"() {
    init_extends();
    init_type();
    init_config();
    init_guid();
    init_extend();
    init_errors();
    init_object();
    init_data();
    init_utils();
  }
});

// node_modules/devextreme/esm/data/custom_store.js
var custom_store_exports = {};
__export(custom_store_exports, {
  default: () => custom_store_default
});
function isPromise(obj) {
  return obj && isFunction(obj.then);
}
function trivialPromise2(value) {
  return new Deferred().resolve(value).promise();
}
function ensureRequiredFuncOption(name, obj) {
  if (!isFunction(obj)) {
    throw errors.Error("E4011", name);
  }
}
function throwInvalidUserFuncResult(name) {
  throw errors.Error("E4012", name);
}
function createUserFuncFailureHandler(pendingDeferred) {
  return function(arg) {
    let error;
    if (arg instanceof Error) {
      error = arg;
    } else {
      error = new Error(function(promiseArguments) {
        const xhr = promiseArguments[0];
        const textStatus = promiseArguments[1];
        if (!xhr || !xhr.getResponseHeader) {
          return null;
        }
        return errorMessageFromXhr(xhr, textStatus);
      }(arguments) || arg && String(arg) || "Unknown error");
    }
    if (error.message !== XHR_ERROR_UNLOAD) {
      pendingDeferred.reject(error);
    }
  };
}
function invokeUserLoad(store, options) {
  const userFunc = store._loadFunc;
  let userResult;
  ensureRequiredFuncOption(LOAD, userFunc);
  userResult = userFunc.apply(store, [options]);
  if (Array.isArray(userResult)) {
    userResult = trivialPromise2(userResult);
  } else if (null === userResult || void 0 === userResult) {
    userResult = trivialPromise2([]);
  } else if (!isPromise(userResult)) {
    throwInvalidUserFuncResult(LOAD);
  }
  return fromPromise(userResult);
}
function invokeUserTotalCountFunc(store, options) {
  const userFunc = store._totalCountFunc;
  let userResult;
  if (!isFunction(userFunc)) {
    throw errors.Error("E4021");
  }
  userResult = userFunc.apply(store, [options]);
  if (!isPromise(userResult)) {
    userResult = Number(userResult);
    if (!isFinite(userResult)) {
      throwInvalidUserFuncResult(TOTAL_COUNT);
    }
    userResult = trivialPromise2(userResult);
  }
  return fromPromise(userResult);
}
function invokeUserByKeyFunc(store, key, extraOptions) {
  const userFunc = store._byKeyFunc;
  let userResult;
  ensureRequiredFuncOption(BY_KEY, userFunc);
  userResult = userFunc.apply(store, [key, extraOptions]);
  if (!isPromise(userResult)) {
    userResult = trivialPromise2(userResult);
  }
  return fromPromise(userResult);
}
function runRawLoad(pendingDeferred, store, userFuncOptions, continuation) {
  if (store.__rawData) {
    continuation(store.__rawData);
  } else {
    const loadPromise = store.__rawDataPromise || invokeUserLoad(store, userFuncOptions);
    if (store._cacheRawData) {
      store.__rawDataPromise = loadPromise;
    }
    loadPromise.always(function() {
      delete store.__rawDataPromise;
    }).done(function(rawData) {
      if (store._cacheRawData) {
        store.__rawData = rawData;
      }
      continuation(rawData);
    }).fail((error) => {
      var _store$_errorHandler;
      const userFuncFailureHandler = createUserFuncFailureHandler(pendingDeferred);
      null === (_store$_errorHandler = store._errorHandler) || void 0 === _store$_errorHandler || _store$_errorHandler.call(store, error);
      userFuncFailureHandler(error);
    });
  }
}
function runRawLoadWithQuery(pendingDeferred, store, options, countOnly) {
  options = options || {};
  const userFuncOptions = {};
  if ("userData" in options) {
    userFuncOptions.userData = options.userData;
  }
  runRawLoad(pendingDeferred, store, userFuncOptions, function(rawData) {
    const rawDataQuery = array_query_default(rawData, {
      errorHandler: store._errorHandler
    });
    let itemsQuery;
    let totalCountQuery;
    const waitList = [];
    let items;
    let totalCount;
    if (!countOnly) {
      itemsQuery = store_helper_default.queryByOptions(rawDataQuery, options);
      if (itemsQuery === rawDataQuery) {
        items = rawData.slice(0);
      } else {
        waitList.push(itemsQuery.enumerate().done(function(asyncResult) {
          items = asyncResult;
        }));
      }
    }
    if (options.requireTotalCount || countOnly) {
      totalCountQuery = store_helper_default.queryByOptions(rawDataQuery, options, true);
      if (totalCountQuery === rawDataQuery) {
        totalCount = rawData.length;
      } else {
        waitList.push(totalCountQuery.count().done(function(asyncResult) {
          totalCount = asyncResult;
        }));
      }
    }
    when.apply(renderer_default, waitList).done(function() {
      if (countOnly) {
        pendingDeferred.resolve(totalCount);
      } else if (options.requireTotalCount) {
        pendingDeferred.resolve(items, {
          totalCount
        });
      } else {
        pendingDeferred.resolve(items);
      }
    }).fail(function(x) {
      pendingDeferred.reject(x);
    });
  });
}
function runRawLoadWithKey(pendingDeferred, store, key) {
  runRawLoad(pendingDeferred, store, {}, function(rawData) {
    const keyExpr = store.key();
    let item;
    for (let i = 0, len = rawData.length; i < len; i++) {
      item = rawData[i];
      if (keysEqual(keyExpr, store.keyOf(rawData[i]), key)) {
        pendingDeferred.resolve(item);
        return;
      }
    }
    pendingDeferred.reject(errors.Error("E4009"));
  });
}
var TOTAL_COUNT, LOAD, BY_KEY, INSERT, UPDATE, REMOVE, CustomStore, custom_store_default;
var init_custom_store = __esm({
  "node_modules/devextreme/esm/data/custom_store.js"() {
    init_renderer();
    init_utils();
    init_array_utils();
    init_type();
    init_config();
    init_errors();
    init_abstract_store();
    init_array_query();
    init_store_helper();
    init_deferred();
    TOTAL_COUNT = "totalCount";
    LOAD = "load";
    BY_KEY = "byKey";
    INSERT = "insert";
    UPDATE = "update";
    REMOVE = "remove";
    CustomStore = abstract_store_default.inherit({
      ctor: function(options) {
        options = options || {};
        this.callBase(options);
        this._useDefaultSearch = !!options.useDefaultSearch || "raw" === options.loadMode;
        this._loadMode = options.loadMode;
        this._cacheRawData = false !== options.cacheRawData;
        this._loadFunc = options[LOAD];
        this._totalCountFunc = options[TOTAL_COUNT];
        this._byKeyFunc = options[BY_KEY];
        this._insertFunc = options[INSERT];
        this._updateFunc = options[UPDATE];
        this._removeFunc = options[REMOVE];
      },
      _clearCache() {
        delete this.__rawData;
      },
      createQuery: function() {
        throw errors.Error("E4010");
      },
      clearRawDataCache: function() {
        this._clearCache();
      },
      _totalCountImpl: function(options) {
        let d = new Deferred();
        if ("raw" === this._loadMode && !this._totalCountFunc) {
          runRawLoadWithQuery(d, this, options, true);
        } else {
          invokeUserTotalCountFunc(this, options).done(function(count) {
            d.resolve(Number(count));
          }).fail(createUserFuncFailureHandler(d));
          d = this._addFailHandlers(d);
        }
        return d.promise();
      },
      _pushImpl: function(changes) {
        if (this.__rawData) {
          applyBatch({
            keyInfo: this,
            data: this.__rawData,
            changes
          });
        }
      },
      _loadImpl: function(options) {
        let d = new Deferred();
        if ("raw" === this._loadMode) {
          runRawLoadWithQuery(d, this, options, false);
        } else {
          invokeUserLoad(this, options).done(function(data, extra) {
            d.resolve(data, extra);
          }).fail(createUserFuncFailureHandler(d));
          d = this._addFailHandlers(d);
        }
        return d.promise();
      },
      _byKeyImpl: function(key, extraOptions) {
        const d = new Deferred();
        if (this._byKeyViaLoad()) {
          this._requireKey();
          runRawLoadWithKey(d, this, key);
        } else {
          invokeUserByKeyFunc(this, key, extraOptions).done(function(obj) {
            d.resolve(obj);
          }).fail(createUserFuncFailureHandler(d));
        }
        return d.promise();
      },
      _byKeyViaLoad: function() {
        return "raw" === this._loadMode && !this._byKeyFunc;
      },
      _insertImpl: function(values) {
        const that = this;
        const userFunc = that._insertFunc;
        let userResult;
        const d = new Deferred();
        ensureRequiredFuncOption(INSERT, userFunc);
        userResult = userFunc.apply(that, [values]);
        if (!isPromise(userResult)) {
          userResult = trivialPromise2(userResult);
        }
        fromPromise(userResult).done(function(serverResponse) {
          if (config_default().useLegacyStoreResult) {
            d.resolve(values, serverResponse);
          } else {
            d.resolve(serverResponse || values, that.keyOf(serverResponse));
          }
        }).fail(createUserFuncFailureHandler(d));
        return d.promise();
      },
      _updateImpl: function(key, values) {
        const userFunc = this._updateFunc;
        let userResult;
        const d = new Deferred();
        ensureRequiredFuncOption(UPDATE, userFunc);
        userResult = userFunc.apply(this, [key, values]);
        if (!isPromise(userResult)) {
          userResult = trivialPromise2(userResult);
        }
        fromPromise(userResult).done(function(serverResponse) {
          if (config_default().useLegacyStoreResult) {
            d.resolve(key, values);
          } else {
            d.resolve(serverResponse || values, key);
          }
        }).fail(createUserFuncFailureHandler(d));
        return d.promise();
      },
      _removeImpl: function(key) {
        const userFunc = this._removeFunc;
        let userResult;
        const d = new Deferred();
        ensureRequiredFuncOption(REMOVE, userFunc);
        userResult = userFunc.apply(this, [key]);
        if (!isPromise(userResult)) {
          userResult = trivialPromise2();
        }
        fromPromise(userResult).done(function() {
          d.resolve(key);
        }).fail(createUserFuncFailureHandler(d));
        return d.promise();
      }
    });
    custom_store_default = CustomStore;
  }
});

export {
  createObjectWithChanges,
  applyBatch,
  update,
  insert,
  remove,
  indexByKey,
  init_array_utils,
  custom_store_default,
  custom_store_exports,
  init_custom_store
};
//# sourceMappingURL=chunk-VVVI3OU6.js.map
