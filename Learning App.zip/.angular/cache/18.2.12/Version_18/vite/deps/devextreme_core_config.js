import {
  config_default,
  init_config
} from "./chunk-ND5ICVCX.js";
import "./chunk-WOR4A3D2.js";
init_config();
export {
  config_default as default
};
//# sourceMappingURL=devextreme_core_config.js.map
