import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-4ES6BYTB.js";
import "./chunk-BULAZH4H.js";
import "./chunk-WBCLGCHV.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-EBLT4CH3.js";
import "./chunk-74ZAWBSC.js";
import "./chunk-WOR4A3D2.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
