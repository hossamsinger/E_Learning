import {
  __esm,
  __export
} from "./chunk-WOR4A3D2.js";

// node_modules/devextreme/esm/core/utils/type.js
var types, type, isBoolean, isExponential, isDate, isDefined, isFunction, isString, isNumeric, isObject, isEmptyObject, isPlainObject, isPrimitive, isWindow, isRenderer, isPromise, isDeferred, isEvent;
var init_type = __esm({
  "node_modules/devextreme/esm/core/utils/type.js"() {
    types = {
      "[object Array]": "array",
      "[object Date]": "date",
      "[object Object]": "object",
      "[object String]": "string"
    };
    type = function(object) {
      if (null === object) {
        return "null";
      }
      const typeOfObject = Object.prototype.toString.call(object);
      return "object" === typeof object ? types[typeOfObject] || "object" : typeof object;
    };
    isBoolean = function(object) {
      return "boolean" === typeof object;
    };
    isExponential = function(value) {
      return isNumeric(value) && -1 !== value.toString().indexOf("e");
    };
    isDate = function(object) {
      return "date" === type(object);
    };
    isDefined = function(object) {
      return null !== object && void 0 !== object;
    };
    isFunction = function(object) {
      return "function" === typeof object;
    };
    isString = function(object) {
      return "string" === typeof object;
    };
    isNumeric = function(object) {
      return "number" === typeof object && isFinite(object) || !isNaN(object - parseFloat(object));
    };
    isObject = function(object) {
      return "object" === type(object);
    };
    isEmptyObject = function(object) {
      let property;
      for (property in object) {
        return false;
      }
      return true;
    };
    isPlainObject = function(object) {
      if (!object || "object" !== type(object)) {
        return false;
      }
      const proto = Object.getPrototypeOf(object);
      if (!proto) {
        return true;
      }
      const ctor = Object.hasOwnProperty.call(proto, "constructor") && proto.constructor;
      return "function" === typeof ctor && Object.toString.call(ctor) === Object.toString.call(Object);
    };
    isPrimitive = function(value) {
      return -1 === ["object", "array", "function"].indexOf(type(value));
    };
    isWindow = function(object) {
      return null != object && object === object.window;
    };
    isRenderer = function(object) {
      return !!object && !!(object.jquery || object.dxRenderer);
    };
    isPromise = function(object) {
      return !!object && isFunction(object.then);
    };
    isDeferred = function(object) {
      return !!object && isFunction(object.done) && isFunction(object.fail);
    };
    isEvent = function(object) {
      return !!(object && object.preventDefault);
    };
  }
});

// node_modules/devextreme/esm/core/utils/extend.js
var extend_exports = {};
__export(extend_exports, {
  extend: () => extend,
  extendFromObject: () => extendFromObject
});
var extendFromObject, extend;
var init_extend = __esm({
  "node_modules/devextreme/esm/core/utils/extend.js"() {
    init_type();
    extendFromObject = function(target, source, overrideExistingValues) {
      target = target || {};
      for (const prop in source) {
        if (Object.prototype.hasOwnProperty.call(source, prop)) {
          const value = source[prop];
          if (!(prop in target) || overrideExistingValues) {
            target[prop] = value;
          }
        }
      }
      return target;
    };
    extend = function(target) {
      target = target || {};
      let i = 1;
      let deep = false;
      if ("boolean" === typeof target) {
        deep = target;
        target = arguments[1] || {};
        i++;
      }
      for (; i < arguments.length; i++) {
        const source = arguments[i];
        if (null == source) {
          continue;
        }
        for (const key in source) {
          const targetValue = target[key];
          const sourceValue = source[key];
          let sourceValueIsArray = false;
          let clone;
          if ("__proto__" === key || "constructor" === key || target === sourceValue) {
            continue;
          }
          if (deep && sourceValue && (isPlainObject(sourceValue) || (sourceValueIsArray = Array.isArray(sourceValue)))) {
            if (sourceValueIsArray) {
              clone = targetValue && Array.isArray(targetValue) ? targetValue : [];
            } else {
              clone = targetValue && isPlainObject(targetValue) ? targetValue : {};
            }
            target[key] = extend(deep, clone, sourceValue);
          } else if (void 0 !== sourceValue) {
            target[key] = sourceValue;
          }
        }
      }
      return target;
    };
  }
});

// node_modules/devextreme/esm/core/utils/console.js
var noop, getConsoleMethod, logger;
var init_console = __esm({
  "node_modules/devextreme/esm/core/utils/console.js"() {
    init_type();
    noop = function() {
    };
    getConsoleMethod = function(method) {
      if ("undefined" === typeof console || !isFunction(console[method])) {
        return noop;
      }
      return console[method].bind(console);
    };
    logger = {
      log: getConsoleMethod("log"),
      info: getConsoleMethod("info"),
      warn: getConsoleMethod("warn"),
      error: getConsoleMethod("error")
    };
  }
});

// node_modules/devextreme/esm/core/utils/string.js
function format(template) {
  for (var _len = arguments.length, values = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    values[_key - 1] = arguments[_key];
  }
  if (isFunction(template)) {
    return template(...values);
  }
  values.forEach((value, index) => {
    if (isString(value)) {
      value = value.replace(/\$/g, "$$$$");
    }
    const placeholderReg = new RegExp("\\{" + index + "\\}", "gm");
    template = template.replace(placeholderReg, value);
  });
  return template;
}
var encodeHtml, splitQuad, quadToObject, isEmpty;
var init_string = __esm({
  "node_modules/devextreme/esm/core/utils/string.js"() {
    init_type();
    encodeHtml = function() {
      const encodeRegExp = [new RegExp("&", "g"), new RegExp('"', "g"), new RegExp("'", "g"), new RegExp("<", "g"), new RegExp(">", "g")];
      return function(str) {
        return String(str).replace(encodeRegExp[0], "&amp;").replace(encodeRegExp[1], "&quot;").replace(encodeRegExp[2], "&#39;").replace(encodeRegExp[3], "&lt;").replace(encodeRegExp[4], "&gt;");
      };
    }();
    splitQuad = function(raw) {
      switch (typeof raw) {
        case "string":
          return raw.split(/\s+/, 4);
        case "object":
          return [raw.x || raw.h || raw.left, raw.y || raw.v || raw.top, raw.x || raw.h || raw.right, raw.y || raw.v || raw.bottom];
        case "number":
          return [raw];
        default:
          return raw;
      }
    };
    quadToObject = function(raw) {
      const quad = splitQuad(raw);
      let left = parseInt(quad && quad[0], 10);
      let top = parseInt(quad && quad[1], 10);
      let right = parseInt(quad && quad[2], 10);
      let bottom = parseInt(quad && quad[3], 10);
      if (!isFinite(left)) {
        left = 0;
      }
      if (!isFinite(top)) {
        top = left;
      }
      if (!isFinite(right)) {
        right = left;
      }
      if (!isFinite(bottom)) {
        bottom = top;
      }
      return {
        top,
        right,
        bottom,
        left
      };
    };
    isEmpty = /* @__PURE__ */ function() {
      const SPACE_REGEXP = /\s/g;
      return function(text) {
        return !text || !text.replace(SPACE_REGEXP, "");
      };
    }();
  }
});

// node_modules/devextreme/esm/core/version.js
var version, fullVersion;
var init_version = __esm({
  "node_modules/devextreme/esm/core/version.js"() {
    version = "24.1.8";
    fullVersion = "24.1.8";
  }
});

// node_modules/devextreme/esm/core/utils/error.js
function error_default(baseErrors, errors) {
  const exports = {
    ERROR_MESSAGES: extend(errors, baseErrors),
    Error: function() {
      return function(args) {
        const id = args[0];
        args = args.slice(1);
        const details = formatDetails(id, args);
        const url = getErrorUrl(id);
        const message = formatMessage(id, details);
        return extend(new Error(message), {
          __id: id,
          __details: details,
          url
        });
      }([].slice.call(arguments));
    },
    log: function(id) {
      let method = "log";
      if (/^E\d+$/.test(id)) {
        method = "error";
      } else if (/^W\d+$/.test(id)) {
        method = "warn";
      }
      logger[method]("log" === method ? id : function(args) {
        const id2 = args[0];
        args = args.slice(1);
        return formatMessage(id2, formatDetails(id2, args));
      }([].slice.call(arguments)));
    }
  };
  function formatDetails(id, args) {
    args = [exports.ERROR_MESSAGES[id]].concat(args);
    return format.apply(this, args).replace(/\.*\s*?$/, "");
  }
  function formatMessage(id, details) {
    const kind = null !== id && void 0 !== id && id.startsWith("W") ? "warning" : "error";
    return format.apply(this, ["{0} - {1}.\n\nFor additional information on this {2} message, see: {3}", id, details, kind, getErrorUrl(id)]);
  }
  function getErrorUrl(id) {
    return ERROR_URL + id;
  }
  return exports;
}
var ERROR_URL;
var init_error = __esm({
  "node_modules/devextreme/esm/core/utils/error.js"() {
    init_extend();
    init_console();
    init_string();
    init_version();
    ERROR_URL = "https://js.devexpress.com/error/" + version.split(".").slice(0, 2).join("_") + "/";
  }
});

// node_modules/devextreme/esm/core/errors.js
var errors_default;
var init_errors = __esm({
  "node_modules/devextreme/esm/core/errors.js"() {
    init_error();
    errors_default = error_default({
      E0001: "Method is not implemented",
      E0002: "Member name collision: {0}",
      E0003: "A class must be instantiated using the 'new' keyword",
      E0004: "The NAME property of the component is not specified",
      E0005: "Unknown device",
      E0006: "Unknown endpoint key is requested",
      E0007: "'Invalidate' method is called outside the update transaction",
      E0008: "Type of the option name is not appropriate to create an action",
      E0009: "Component '{0}' has not been initialized for an element",
      E0010: "Animation configuration with the '{0}' type requires '{1}' configuration as {2}",
      E0011: "Unknown animation type '{0}'",
      E0012: "jQuery version is too old. Please upgrade jQuery to 1.10.0 or later",
      E0013: "KnockoutJS version is too old. Please upgrade KnockoutJS to 2.3.0 or later",
      E0014: "The 'release' method shouldn't be called for an unlocked Lock object",
      E0015: "Queued task returned an unexpected result",
      E0017: "Event namespace is not defined",
      E0018: "DevExpress.ui.DevExpressPopup widget is required",
      E0020: "Template engine '{0}' is not supported",
      E0021: "Unknown theme is set: {0}",
      E0022: "LINK[rel=DevExpress-theme] tags must go before DevExpress included scripts",
      E0023: "Template name is not specified",
      E0024: "DevExtreme bundle already included",
      E0025: "Unexpected argument type",
      E0100: "Unknown validation type is detected",
      E0101: "Misconfigured range validation rule is detected",
      E0102: "Misconfigured comparison validation rule is detected",
      E0103: "validationCallback of an asynchronous rule should return a jQuery or a native promise",
      E0110: "Unknown validation group is detected",
      E0120: "Adapter for a DevExpressValidator component cannot be configured",
      E0121: "The 'customItem' parameter of the 'onCustomItemCreating' function is empty or contains invalid data. Assign a custom object or a Promise that is resolved after the item is created.",
      W0000: "'{0}' is deprecated in {1}. {2}",
      W0001: "{0} - '{1}' option is deprecated in {2}. {3}",
      W0002: "{0} - '{1}' method is deprecated in {2}. {3}",
      W0003: "{0} - '{1}' property is deprecated in {2}. {3}",
      W0004: "Timeout for theme loading is over: {0}",
      W0005: "'{0}' event is deprecated in {1}. {2}",
      W0006: "Invalid recurrence rule: '{0}'",
      W0007: "'{0}' Globalize culture is not defined",
      W0008: "Invalid view name: '{0}'",
      W0009: "Invalid time zone name: '{0}'",
      W0010: "{0} is deprecated in {1}. {2}",
      W0011: "Number parsing is invoked while the parser is not defined",
      W0012: "Date parsing is invoked while the parser is not defined",
      W0013: "'{0}' file is deprecated in {1}. {2}",
      W0014: "{0} - '{1}' type is deprecated in {2}. {3}",
      W0015: "Instead of returning a value from the '{0}' function, write it into the '{1}' field of the function's parameter.",
      W0016: 'The "{0}" option does not accept the "{1}" value since v{2}. {3}.',
      W0017: 'Setting the "{0}" property with a function is deprecated since v21.2',
      W0018: 'Setting the "position" property with a function is deprecated since v21.2',
      W0019: "DevExtreme: Unable to Locate a Valid License Key.\n\nDetailed license/registration related information and instructions: https://js.devexpress.com/Documentation/Licensing/.\n\nIf you are using a 30-day trial version of DevExtreme, you must uninstall all copies of DevExtreme once your 30-day trial period expires. For terms and conditions that govern use of DevExtreme UI components/libraries, please refer to the DevExtreme End User License Agreement: https://js.devexpress.com/EULAs/DevExtremeComplete.\n\nTo use DevExtreme in a commercial project, you must purchase a license. For pricing/licensing options, please visit: https://js.devexpress.com/Buy.\n\nIf you have licensing-related questions or need help with a purchase, please email clientservices@devexpress.com.\n\n",
      W0020: "DevExtreme: License Key Has Expired.\n\nDetailed license/registration related information and instructions: https://js.devexpress.com/Documentation/Licensing/.\n\nA mismatch exists between the license key used and the DevExtreme version referenced in this project.\n\nTo proceed, you can:\n• use a version of DevExtreme linked to your license key: https://www.devexpress.com/ClientCenter/DownloadManager\n• renew your DevExpress Subscription: https://www.devexpress.com/buy/renew (once you renew your subscription, you will be entitled to product updates and support service as defined in the DevExtreme End User License Agreement)\n\nIf you have licensing-related questions or need help with a renewal, please email clientservices@devexpress.com.\n\n",
      W0021: "DevExtreme: License Key Verification Has Failed.\n\nDetailed license/registration related information and instructions: https://js.devexpress.com/Documentation/Licensing/.\n\nTo verify your DevExtreme license, make certain to specify a correct key in the GlobalConfig. If you continue to encounter this error, please visit https://www.devexpress.com/ClientCenter/DownloadManager to obtain a valid license key.\n\nIf you have a valid license and this problem persists, please submit a support ticket via the DevExpress Support Center. We will be happy to follow-up: https://supportcenter.devexpress.com/ticket/create.\n\n",
      W0022: "DevExtreme: Pre-release software. Not suitable for commercial use.\n\nDetailed license/registration related information and instructions: https://js.devexpress.com/Documentation/Licensing/.\n\nPre-release software may contain deficiencies and as such, should not be considered for use or integrated in any mission critical application.\n\n",
      W0023: "DevExtreme: the following 'devextreme' package version does not match versions of other DevExpress products used in this application:\n\n{0}\n\nInteroperability between different versions of the products listed herein cannot be guaranteed.\n\n"
    });
  }
});

// node_modules/devextreme/esm/core/config.js
var config, normalizeToJSONString, deprecatedFields, configMethod, config_default;
var init_config = __esm({
  "node_modules/devextreme/esm/core/config.js"() {
    init_extend();
    init_errors();
    config = {
      rtlEnabled: false,
      defaultCurrency: "USD",
      defaultUseCurrencyAccountingStyle: true,
      oDataFilterToLower: true,
      serverDecimalSeparator: ".",
      decimalSeparator: ".",
      thousandsSeparator: ",",
      forceIsoDateParsing: true,
      wrapActionsBeforeExecute: true,
      useLegacyStoreResult: false,
      useJQuery: void 0,
      editorStylingMode: void 0,
      useLegacyVisibleIndex: false,
      floatingActionButtonConfig: {
        icon: "add",
        closeIcon: "close",
        label: "",
        position: {
          at: "right bottom",
          my: "right bottom",
          offset: {
            x: -16,
            y: -16
          }
        },
        maxSpeedDialActionCount: 5,
        shading: false,
        direction: "auto"
      },
      optionsParser: (optionsString) => {
        if ("{" !== optionsString.trim().charAt(0)) {
          optionsString = "{" + optionsString + "}";
        }
        try {
          return JSON.parse(optionsString);
        } catch (ex) {
          try {
            return JSON.parse(normalizeToJSONString(optionsString));
          } catch (exNormalize) {
            throw errors_default.Error("E3018", ex, optionsString);
          }
        }
      }
    };
    normalizeToJSONString = (optionsString) => optionsString.replace(/'/g, '"').replace(/,\s*([\]}])/g, "$1").replace(/([{,])\s*([^":\s]+)\s*:/g, '$1"$2":');
    deprecatedFields = ["decimalSeparator", "thousandsSeparator"];
    configMethod = function() {
      if (!arguments.length) {
        return config;
      }
      const newConfig = arguments.length <= 0 ? void 0 : arguments[0];
      deprecatedFields.forEach((deprecatedField) => {
        if (newConfig[deprecatedField]) {
          const message = `Now, the ${deprecatedField} is selected based on the specified locale.`;
          errors_default.log("W0003", "config", deprecatedField, "19.2", message);
        }
      });
      extend(config, newConfig);
    };
    if ("undefined" !== typeof DevExpress && DevExpress.config) {
      configMethod(DevExpress.config);
    }
    config_default = configMethod;
  }
});

export {
  type,
  isBoolean,
  isExponential,
  isDate,
  isDefined,
  isFunction,
  isString,
  isNumeric,
  isObject,
  isEmptyObject,
  isPlainObject,
  isPrimitive,
  isWindow,
  isRenderer,
  isPromise,
  isDeferred,
  isEvent,
  init_type,
  extendFromObject,
  extend,
  extend_exports,
  init_extend,
  logger,
  init_console,
  encodeHtml,
  quadToObject,
  format,
  isEmpty,
  init_string,
  version,
  fullVersion,
  init_version,
  error_default,
  init_error,
  errors_default,
  init_errors,
  config_default,
  init_config
};
//# sourceMappingURL=chunk-ND5ICVCX.js.map
