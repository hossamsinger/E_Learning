import {
  call_once_default,
  callbacks_default,
  dependency_injector_default,
  dom_adapter_default,
  each,
  getWindow,
  hasWindow,
  init_call_once,
  init_callbacks,
  init_dependency_injector,
  init_dom_adapter,
  init_iterator,
  init_window,
  map
} from "./chunk-TEJ7FDOJ.js";
import {
  errors_default,
  extend,
  init_errors,
  init_extend,
  init_type,
  isDefined,
  isFunction,
  isNumeric,
  isObject,
  isPlainObject,
  isRenderer,
  isString,
  isWindow,
  type
} from "./chunk-ND5ICVCX.js";
import {
  __esm
} from "./chunk-WOR4A3D2.js";

// node_modules/devextreme/esm/core/memorized_callbacks.js
var MemorizedCallbacks;
var init_memorized_callbacks = __esm({
  "node_modules/devextreme/esm/core/memorized_callbacks.js"() {
    init_iterator();
    init_callbacks();
    MemorizedCallbacks = class {
      constructor() {
        this.memory = [];
        this.callbacks = callbacks_default();
      }
      add(fn) {
        each(this.memory, (_, item) => fn.apply(fn, item));
        this.callbacks.add(fn);
      }
      remove(fn) {
        this.callbacks.remove(fn);
      }
      fire() {
        for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }
        this.memory.push(args);
        this.callbacks.fire.apply(this.callbacks, args);
      }
    };
  }
});

// node_modules/devextreme/esm/events/core/event_registrator_callbacks.js
var event_registrator_callbacks_default;
var init_event_registrator_callbacks = __esm({
  "node_modules/devextreme/esm/events/core/event_registrator_callbacks.js"() {
    init_memorized_callbacks();
    event_registrator_callbacks_default = new MemorizedCallbacks();
  }
});

// node_modules/devextreme/esm/events/utils/event_target.js
var getEventTarget;
var init_event_target = __esm({
  "node_modules/devextreme/esm/events/utils/event_target.js"() {
    getEventTarget = (event) => {
      var _originalEvent$target, _originalEvent$compos;
      const originalEvent = event.originalEvent;
      if (!originalEvent) {
        return event.target;
      }
      const isShadowDOMUsed = Boolean(null === (_originalEvent$target = originalEvent.target) || void 0 === _originalEvent$target ? void 0 : _originalEvent$target.shadowRoot);
      if (!isShadowDOMUsed) {
        return originalEvent.target;
      }
      const path = originalEvent.path ?? (null === (_originalEvent$compos = originalEvent.composedPath) || void 0 === _originalEvent$compos ? void 0 : _originalEvent$compos.call(originalEvent));
      const target = (null === path || void 0 === path ? void 0 : path[0]) ?? event.target;
      return target;
    };
  }
});

// node_modules/devextreme/esm/events/core/hook_touch_props.js
function hook_touch_props_default(callback) {
  touchPropsToHook.forEach(function(name) {
    callback(name, function(event) {
      return touchPropHook(name, event);
    });
  }, this);
}
var touchPropsToHook, touchPropHook;
var init_hook_touch_props = __esm({
  "node_modules/devextreme/esm/events/core/hook_touch_props.js"() {
    touchPropsToHook = ["pageX", "pageY", "screenX", "screenY", "clientX", "clientY"];
    touchPropHook = function(name, event) {
      if (event[name] && !event.touches || !event.touches) {
        return event[name];
      }
      const touches = event.touches.length ? event.touches : event.changedTouches;
      if (!touches.length) {
        return;
      }
      return touches[0][name];
    };
  }
});

// node_modules/devextreme/esm/events/core/events_engine.js
function matchesSafe(target, selector) {
  return !isWindow(target) && "#document" !== target.nodeName && dom_adapter_default.elementMatches(target, selector);
}
function applyForEach(args, method) {
  const element = args[0];
  if (!element) {
    return;
  }
  if (dom_adapter_default.isNode(element) || isWindow(element)) {
    method.apply(eventsEngine, args);
  } else if (!isString(element) && "length" in element) {
    const itemArgs = Array.prototype.slice.call(args, 0);
    Array.prototype.forEach.call(element, function(itemElement) {
      itemArgs[0] = itemElement;
      applyForEach(itemArgs, method);
    });
  } else {
    throw errors_default.Error("E0025");
  }
}
function getHandler(method) {
  return function() {
    applyForEach(arguments, method);
  };
}
function detectPassiveEventHandlersSupport() {
  let isSupported = false;
  try {
    const options = Object.defineProperty({}, "passive", {
      get: function() {
        isSupported = true;
        return true;
      }
    });
    window.addEventListener("test", null, options);
  } catch (e) {
  }
  return isSupported;
}
function getHandlersController(element, eventName) {
  let elementData = elementDataMap.get(element);
  eventName = eventName || "";
  const eventNameParts = eventName.split(".");
  const namespaces = eventNameParts.slice(1);
  const eventNameIsDefined = !!eventNameParts[0];
  eventName = eventNameParts[0] || EMPTY_EVENT_NAME;
  if (!elementData) {
    elementData = {};
    elementDataMap.set(element, elementData);
  }
  if (!elementData[eventName]) {
    elementData[eventName] = {
      handleObjects: [],
      nativeHandler: null
    };
  }
  const eventData = elementData[eventName];
  return {
    addHandler: function(handler, selector, data2) {
      const callHandler = function(e, extraParameters) {
        const handlerArgs = [e];
        const target = e.currentTarget;
        const relatedTarget = e.relatedTarget;
        let secondaryTargetIsInside;
        let result;
        if (eventName in NATIVE_EVENTS_TO_SUBSCRIBE) {
          secondaryTargetIsInside = relatedTarget && target && (relatedTarget === target || contains(target, relatedTarget));
        }
        if (void 0 !== extraParameters) {
          handlerArgs.push(extraParameters);
        }
        special.callMethod(eventName, "handle", element, [e, data2]);
        if (!secondaryTargetIsInside) {
          result = handler.apply(target, handlerArgs);
        }
        if (false === result) {
          e.preventDefault();
          e.stopPropagation();
        }
      };
      const handleObject = {
        handler,
        wrappedHandler: function(e, extraParameters) {
          if (skipEvent && e.type === skipEvent) {
            return;
          }
          e.data = data2;
          e.delegateTarget = element;
          if (selector) {
            let currentTarget = e.target;
            while (currentTarget && currentTarget !== element) {
              if (matchesSafe(currentTarget, selector)) {
                e.currentTarget = currentTarget;
                callHandler(e, extraParameters);
              }
              currentTarget = currentTarget.parentNode;
            }
          } else {
            var _e$target;
            e.currentTarget = e.delegateTarget || e.target;
            const isTargetInShadowDOM = Boolean(null === (_e$target = e.target) || void 0 === _e$target ? void 0 : _e$target.shadowRoot);
            if (isTargetInShadowDOM) {
              const target = getEventTarget(e);
              e.target = target;
            }
            callHandler(e, extraParameters);
          }
        },
        selector,
        type: eventName,
        data: data2,
        namespace: namespaces.join("."),
        namespaces,
        guid: ++guid
      };
      eventData.handleObjects.push(handleObject);
      const firstHandlerForTheType = 1 === eventData.handleObjects.length;
      let shouldAddNativeListener = firstHandlerForTheType && eventNameIsDefined;
      let nativeListenerOptions;
      if (shouldAddNativeListener) {
        shouldAddNativeListener = !special.callMethod(eventName, "setup", element, [data2, namespaces, handler]);
      }
      if (shouldAddNativeListener) {
        eventData.nativeHandler = getNativeHandler(eventName);
        if (passiveEventHandlersSupported() && forcePassiveFalseEventNames.indexOf(eventName) > -1) {
          nativeListenerOptions = {
            passive: false
          };
        }
        eventData.removeListener = dom_adapter_default.listen(element, NATIVE_EVENTS_TO_SUBSCRIBE[eventName] || eventName, eventData.nativeHandler, nativeListenerOptions);
      }
      special.callMethod(eventName, "add", element, [handleObject]);
    },
    removeHandler: function(handler, selector) {
      const removeByEventName = function(eventName2) {
        const eventData2 = elementData[eventName2];
        if (!eventData2.handleObjects.length) {
          delete elementData[eventName2];
          return;
        }
        let removedHandler;
        eventData2.handleObjects = eventData2.handleObjects.filter(function(handleObject) {
          const skip = namespaces.length && !isSubset(handleObject.namespaces, namespaces) || handler && handleObject.handler !== handler || selector && handleObject.selector !== selector;
          if (!skip) {
            removedHandler = handleObject.handler;
            special.callMethod(eventName2, "remove", element, [handleObject]);
          }
          return skip;
        });
        const lastHandlerForTheType = !eventData2.handleObjects.length;
        const shouldRemoveNativeListener = lastHandlerForTheType && eventName2 !== EMPTY_EVENT_NAME;
        if (shouldRemoveNativeListener) {
          special.callMethod(eventName2, "teardown", element, [namespaces, removedHandler]);
          if (eventData2.nativeHandler) {
            eventData2.removeListener();
          }
          delete elementData[eventName2];
        }
      };
      if (eventNameIsDefined) {
        removeByEventName(eventName);
      } else {
        for (const name in elementData) {
          removeByEventName(name);
        }
      }
      const elementDataIsEmpty = 0 === Object.keys(elementData).length;
      if (elementDataIsEmpty) {
        elementDataMap.delete(element);
      }
    },
    callHandlers: function(event, extraParameters) {
      let forceStop = false;
      const handleCallback = function(handleObject) {
        if (forceStop) {
          return;
        }
        if (!namespaces.length || isSubset(handleObject.namespaces, namespaces)) {
          handleObject.wrappedHandler(event, extraParameters);
          forceStop = event.isImmediatePropagationStopped();
        }
      };
      eventData.handleObjects.forEach(handleCallback);
      if (namespaces.length && elementData[EMPTY_EVENT_NAME]) {
        elementData[EMPTY_EVENT_NAME].handleObjects.forEach(handleCallback);
      }
    }
  };
}
function getNativeHandler(subscribeName) {
  return function(event, extraParameters) {
    const handlersController = getHandlersController(this, subscribeName);
    event = eventsEngine.Event(event);
    handlersController.callHandlers(event, extraParameters);
  };
}
function isSubset(original, checked) {
  for (let i = 0; i < checked.length; i++) {
    if (original.indexOf(checked[i]) < 0) {
      return false;
    }
  }
  return true;
}
function normalizeOnArguments(callback) {
  return function(element, eventName, selector, data2, handler) {
    if (!handler) {
      handler = data2;
      data2 = void 0;
    }
    if ("string" !== typeof selector) {
      data2 = selector;
      selector = void 0;
    }
    if (!handler && "string" === typeof eventName) {
      handler = data2 || selector;
      selector = void 0;
      data2 = void 0;
    }
    callback(element, eventName, selector, data2, handler);
  };
}
function normalizeOffArguments(callback) {
  return function(element, eventName, selector, handler) {
    if ("function" === typeof selector) {
      handler = selector;
      selector = void 0;
    }
    callback(element, eventName, selector, handler);
  };
}
function normalizeTriggerArguments(callback) {
  return function(element, src, extraParameters) {
    if ("string" === typeof src) {
      src = {
        type: src
      };
    }
    if (!src.target) {
      src.target = element;
    }
    src.currentTarget = element;
    if (!src.delegateTarget) {
      src.delegateTarget = element;
    }
    if (!src.type && src.originalEvent) {
      src.type = src.originalEvent.type;
    }
    callback(element, src instanceof eventsEngine.Event ? src : eventsEngine.Event(src), extraParameters);
  };
}
function normalizeEventArguments(callback) {
  eventsEngine.Event = function(src, config) {
    if (!(this instanceof eventsEngine.Event)) {
      return new eventsEngine.Event(src, config);
    }
    if (!src) {
      src = {};
    }
    if ("string" === typeof src) {
      src = {
        type: src
      };
    }
    if (!config) {
      config = {};
    }
    callback.call(this, src, config);
  };
  Object.assign(eventsEngine.Event.prototype, {
    _propagationStopped: false,
    _immediatePropagationStopped: false,
    _defaultPrevented: false,
    isPropagationStopped: function() {
      return !!(this._propagationStopped || this.originalEvent && this.originalEvent.propagationStopped);
    },
    stopPropagation: function() {
      this._propagationStopped = true;
      this.originalEvent && this.originalEvent.stopPropagation();
    },
    isImmediatePropagationStopped: function() {
      return this._immediatePropagationStopped;
    },
    stopImmediatePropagation: function() {
      this.stopPropagation();
      this._immediatePropagationStopped = true;
      this.originalEvent && this.originalEvent.stopImmediatePropagation();
    },
    isDefaultPrevented: function() {
      return !!(this._defaultPrevented || this.originalEvent && this.originalEvent.defaultPrevented);
    },
    preventDefault: function() {
      this._defaultPrevented = true;
      this.originalEvent && this.originalEvent.preventDefault();
    }
  });
  return eventsEngine.Event;
}
function iterate(callback) {
  const iterateEventNames = function(element, eventName) {
    if (eventName && eventName.indexOf(" ") > -1) {
      const args = Array.prototype.slice.call(arguments, 0);
      eventName.split(" ").forEach(function(eventName2) {
        args[1] = eventName2;
        callback.apply(this, args);
      });
    } else {
      callback.apply(this, arguments);
    }
  };
  return function(element, eventName) {
    if ("object" === typeof eventName) {
      const args = Array.prototype.slice.call(arguments, 0);
      for (const name in eventName) {
        args[1] = name;
        args[args.length - 1] = eventName[name];
        iterateEventNames.apply(this, args);
      }
    } else {
      iterateEventNames.apply(this, arguments);
    }
  };
}
function callNativeMethod(eventName, element) {
  const nativeMethodName = NATIVE_EVENTS_TO_TRIGGER[eventName] || eventName;
  if (function(eventName2, element2) {
    return "click" === eventName2 && "a" === element2.localName;
  }(eventName, element)) {
    return;
  }
  if (isFunction(element[nativeMethodName])) {
    skipEvent = eventName;
    element[nativeMethodName]();
    skipEvent = void 0;
  }
}
function calculateWhich(event) {
  if (function(event2) {
    return null == event2.which && 0 === event2.type.indexOf("key");
  }(event)) {
    return null != event.charCode ? event.charCode : event.keyCode;
  }
  if (function(event2) {
    return !event2.which && void 0 !== event2.button && /^(?:mouse|pointer|contextmenu|drag|drop)|click/.test(event2.type);
  }(event)) {
    const whichByButton = {
      1: 1,
      2: 3,
      3: 1,
      4: 2
    };
    return whichByButton[event.button];
  }
  return event.which;
}
function initEvent(EventClass) {
  if (EventClass) {
    eventsEngine.Event = EventClass;
    eventsEngine.Event.prototype = EventClass.prototype;
  }
}
function addProperty(propName, hook, eventInstance) {
  Object.defineProperty(eventInstance || eventsEngine.Event.prototype, propName, {
    enumerable: true,
    configurable: true,
    get: function() {
      return this.originalEvent && hook(this.originalEvent);
    },
    set: function(value) {
      Object.defineProperty(this, propName, {
        enumerable: true,
        configurable: true,
        writable: true,
        value
      });
    }
  });
}
var window, EMPTY_EVENT_NAME, NATIVE_EVENTS_TO_SUBSCRIBE, NATIVE_EVENTS_TO_TRIGGER, NO_BUBBLE_EVENTS, forcePassiveFalseEventNames, EVENT_PROPERTIES, elementDataMap, guid, skipEvent, special, eventsEngine, passiveEventHandlersSupported, contains, beforeSetStrategy, afterSetStrategy, events_engine_default;
var init_events_engine = __esm({
  "node_modules/devextreme/esm/events/core/events_engine.js"() {
    init_event_registrator_callbacks();
    init_extend();
    init_event_target();
    init_dom_adapter();
    init_window();
    init_dependency_injector();
    init_type();
    init_callbacks();
    init_errors();
    init_hook_touch_props();
    init_call_once();
    window = getWindow();
    EMPTY_EVENT_NAME = "dxEmptyEventType";
    NATIVE_EVENTS_TO_SUBSCRIBE = {
      mouseenter: "mouseover",
      mouseleave: "mouseout",
      pointerenter: "pointerover",
      pointerleave: "pointerout"
    };
    NATIVE_EVENTS_TO_TRIGGER = {
      focusin: "focus",
      focusout: "blur"
    };
    NO_BUBBLE_EVENTS = ["blur", "focus", "load"];
    forcePassiveFalseEventNames = ["touchmove", "wheel", "mousewheel", "touchstart"];
    EVENT_PROPERTIES = ["target", "relatedTarget", "delegateTarget", "altKey", "bubbles", "cancelable", "changedTouches", "ctrlKey", "detail", "eventPhase", "metaKey", "shiftKey", "view", "char", "code", "charCode", "key", "keyCode", "button", "buttons", "offsetX", "offsetY", "pointerId", "pointerType", "targetTouches", "toElement", "touches"];
    elementDataMap = /* @__PURE__ */ new WeakMap();
    guid = 0;
    special = function() {
      const specialData = {};
      event_registrator_callbacks_default.add(function(eventName, eventObject) {
        specialData[eventName] = eventObject;
      });
      return {
        getField: function(eventName, field) {
          return specialData[eventName] && specialData[eventName][field];
        },
        callMethod: function(eventName, methodName, context, args) {
          return specialData[eventName] && specialData[eventName][methodName] && specialData[eventName][methodName].apply(context, args);
        }
      };
    }();
    eventsEngine = dependency_injector_default({
      on: getHandler(normalizeOnArguments(iterate(function(element, eventName, selector, data2, handler) {
        const handlersController = getHandlersController(element, eventName);
        handlersController.addHandler(handler, selector, data2);
      }))),
      one: getHandler(normalizeOnArguments(function(element, eventName, selector, data2, handler) {
        const oneTimeHandler = function() {
          eventsEngine.off(element, eventName, selector, oneTimeHandler);
          handler.apply(this, arguments);
        };
        eventsEngine.on(element, eventName, selector, data2, oneTimeHandler);
      })),
      off: getHandler(normalizeOffArguments(iterate(function(element, eventName, selector, handler) {
        const handlersController = getHandlersController(element, eventName);
        handlersController.removeHandler(handler, selector);
      }))),
      trigger: getHandler(normalizeTriggerArguments(function(element, event, extraParameters) {
        const eventName = event.type;
        const handlersController = getHandlersController(element, event.type);
        special.callMethod(eventName, "trigger", element, [event, extraParameters]);
        handlersController.callHandlers(event, extraParameters);
        const noBubble = special.getField(eventName, "noBubble") || event.isPropagationStopped() || -1 !== NO_BUBBLE_EVENTS.indexOf(eventName);
        if (!noBubble) {
          const parents = [];
          const getParents = function(element2) {
            const parent = element2.parentNode ?? (isObject(element2.host) ? element2.host : null);
            if (parent) {
              parents.push(parent);
              getParents(parent);
            }
          };
          getParents(element);
          parents.push(window);
          let i = 0;
          while (parents[i] && !event.isPropagationStopped()) {
            const parentDataByEvent = getHandlersController(parents[i], event.type);
            parentDataByEvent.callHandlers(extend(event, {
              currentTarget: parents[i]
            }), extraParameters);
            i++;
          }
        }
        if (element.nodeType || isWindow(element)) {
          special.callMethod(eventName, "_default", element, [event, extraParameters]);
          callNativeMethod(eventName, element);
        }
      })),
      triggerHandler: getHandler(normalizeTriggerArguments(function(element, event, extraParameters) {
        const handlersController = getHandlersController(element, event.type);
        handlersController.callHandlers(event, extraParameters);
      }))
    });
    passiveEventHandlersSupported = call_once_default(detectPassiveEventHandlersSupport);
    contains = (container, element) => {
      if (isWindow(container)) {
        return contains(container.document, element);
      }
      return container.contains ? container.contains(element) : !!(element.compareDocumentPosition(container) & element.DOCUMENT_POSITION_CONTAINS);
    };
    initEvent(normalizeEventArguments(function(src, config) {
      var _src$view;
      const srcIsEvent = src instanceof eventsEngine.Event || hasWindow() && src instanceof window.Event || (null === (_src$view = src.view) || void 0 === _src$view ? void 0 : _src$view.Event) && src instanceof src.view.Event;
      if (srcIsEvent) {
        this.originalEvent = src;
        this.type = src.type;
        this.currentTarget = void 0;
        if (Object.prototype.hasOwnProperty.call(src, "isTrusted")) {
          this.isTrusted = src.isTrusted;
        }
        this.timeStamp = src.timeStamp || Date.now();
      } else {
        Object.assign(this, src);
      }
      addProperty("which", calculateWhich, this);
      if (0 === src.type.indexOf("touch")) {
        delete config.pageX;
        delete config.pageY;
      }
      Object.assign(this, config);
      this.guid = ++guid;
    }));
    EVENT_PROPERTIES.forEach((prop) => addProperty(prop, (event) => event[prop]));
    hook_touch_props_default(addProperty);
    beforeSetStrategy = callbacks_default();
    afterSetStrategy = callbacks_default();
    eventsEngine.set = function(engine) {
      beforeSetStrategy.fire();
      eventsEngine.inject(engine);
      initEvent(engine.Event);
      afterSetStrategy.fire();
    };
    eventsEngine.subscribeGlobal = function() {
      applyForEach(arguments, normalizeOnArguments(function() {
        const args = arguments;
        eventsEngine.on.apply(this, args);
        beforeSetStrategy.add(function() {
          const offArgs = Array.prototype.slice.call(args, 0);
          offArgs.splice(3, 1);
          eventsEngine.off.apply(this, offArgs);
        });
        afterSetStrategy.add(function() {
          eventsEngine.on.apply(this, args);
        });
      }));
    };
    eventsEngine.forcePassiveFalseEventNames = forcePassiveFalseEventNames;
    eventsEngine.passiveEventHandlersSupported = passiveEventHandlersSupported;
    events_engine_default = eventsEngine;
  }
});

// node_modules/devextreme/esm/core/element_data.js
function data() {
  return strategy.data.apply(this, arguments);
}
function beforeCleanData(callback) {
  beforeCleanDataFunc = callback;
}
function removeData(element, key) {
  return strategy.removeData.call(this, element, key);
}
function cleanDataRecursive(element, cleanSelf) {
  if (!dom_adapter_default.isElementNode(element)) {
    return;
  }
  const childElements = element.getElementsByTagName("*");
  strategy.cleanData(childElements);
  if (cleanSelf) {
    strategy.cleanData([element]);
  }
}
var dataMap, strategy, strategyChanging, beforeCleanDataFunc, afterCleanDataFunc, setDataStrategy;
var init_element_data = __esm({
  "node_modules/devextreme/esm/core/element_data.js"() {
    init_dom_adapter();
    init_events_engine();
    init_memorized_callbacks();
    dataMap = /* @__PURE__ */ new WeakMap();
    strategyChanging = new MemorizedCallbacks();
    beforeCleanDataFunc = function() {
    };
    afterCleanDataFunc = function() {
    };
    setDataStrategy = function(value) {
      strategyChanging.fire(value);
      strategy = value;
      const cleanData = strategy.cleanData;
      strategy.cleanData = function(nodes) {
        beforeCleanDataFunc(nodes);
        const result = cleanData.call(this, nodes);
        afterCleanDataFunc(nodes);
        return result;
      };
    };
    setDataStrategy({
      data: function() {
        const element = arguments[0];
        const key = arguments[1];
        const value = arguments[2];
        if (!element) {
          return;
        }
        let elementData = dataMap.get(element);
        if (!elementData) {
          elementData = {};
          dataMap.set(element, elementData);
        }
        if (void 0 === key) {
          return elementData;
        }
        if (2 === arguments.length) {
          return elementData[key];
        }
        elementData[key] = value;
        return value;
      },
      removeData: function(element, key) {
        if (!element) {
          return;
        }
        if (void 0 === key) {
          dataMap.delete(element);
        } else {
          const elementData = dataMap.get(element);
          if (elementData) {
            delete elementData[key];
          }
        }
      },
      cleanData: function(elements) {
        for (let i = 0; i < elements.length; i++) {
          events_engine_default.off(elements[i]);
          dataMap.delete(elements[i]);
        }
      }
    });
  }
});

// node_modules/devextreme/esm/core/utils/inflector.js
var _normalize, _upperCaseFirst, _chop, dasherize, camelize, humanize, titleize, DIGIT_CHARS, captionize;
var init_inflector = __esm({
  "node_modules/devextreme/esm/core/utils/inflector.js"() {
    init_iterator();
    _normalize = function(text) {
      if (void 0 === text || null === text) {
        return "";
      }
      return String(text);
    };
    _upperCaseFirst = function(text) {
      return _normalize(text).charAt(0).toUpperCase() + text.substr(1);
    };
    _chop = function(text) {
      return _normalize(text).replace(/([a-z\d])([A-Z])/g, "$1 $2").split(/[\s_-]+/);
    };
    dasherize = function(text) {
      return map(_chop(text), function(p) {
        return p.toLowerCase();
      }).join("-");
    };
    camelize = function(text, upperFirst) {
      return map(_chop(text), function(p, i) {
        p = p.toLowerCase();
        if (upperFirst || i > 0) {
          p = _upperCaseFirst(p);
        }
        return p;
      }).join("");
    };
    humanize = function(text) {
      return _upperCaseFirst(dasherize(text).replace(/-/g, " "));
    };
    titleize = function(text) {
      return map(_chop(text), function(p) {
        return _upperCaseFirst(p.toLowerCase());
      }).join(" ");
    };
    DIGIT_CHARS = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
    captionize = function(name) {
      const captionList = [];
      let i;
      let char;
      let isPrevCharNewWord = false;
      let isNewWord = false;
      for (i = 0; i < name.length; i++) {
        char = name.charAt(i);
        isNewWord = char === char.toUpperCase() && "-" !== char && ")" !== char && "/" !== char || char in DIGIT_CHARS;
        if ("_" === char || "." === char) {
          char = " ";
          isNewWord = true;
        } else if (0 === i) {
          char = char.toUpperCase();
          isNewWord = true;
        } else if (!isPrevCharNewWord && isNewWord) {
          if (captionList.length > 0) {
            captionList.push(" ");
          }
        }
        captionList.push(char);
        isPrevCharNewWord = isNewWord;
      }
      return captionList.join("");
    };
  }
});

// node_modules/devextreme/esm/core/utils/style.js
var jsPrefixes, cssPrefixes, getStyles, forEachPrefixes, styleProp, stylePropPrefix, pxExceptions, normalizeStyleProp, setDimensionProperty, setWidth, setHeight, setStyle;
var init_style = __esm({
  "node_modules/devextreme/esm/core/utils/style.js"() {
    init_inflector();
    init_call_once();
    init_type();
    init_dom_adapter();
    jsPrefixes = ["", "Webkit", "Moz", "O", "Ms"];
    cssPrefixes = {
      "": "",
      Webkit: "-webkit-",
      Moz: "-moz-",
      O: "-o-",
      ms: "-ms-"
    };
    getStyles = call_once_default(function() {
      return dom_adapter_default.createElement("dx").style;
    });
    forEachPrefixes = function(prop, callBack) {
      prop = camelize(prop, true);
      let result;
      for (let i = 0, cssPrefixesCount = jsPrefixes.length; i < cssPrefixesCount; i++) {
        const jsPrefix = jsPrefixes[i];
        const prefixedProp = jsPrefix + prop;
        const lowerPrefixedProp = camelize(prefixedProp);
        result = callBack(lowerPrefixedProp, jsPrefix);
        if (void 0 === result) {
          result = callBack(prefixedProp, jsPrefix);
        }
        if (void 0 !== result) {
          break;
        }
      }
      return result || "";
    };
    styleProp = function(name) {
      if (name in getStyles()) {
        return name;
      }
      const originalName = name;
      name = name.charAt(0).toUpperCase() + name.substr(1);
      for (let i = 1; i < jsPrefixes.length; i++) {
        const prefixedProp = jsPrefixes[i].toLowerCase() + name;
        if (prefixedProp in getStyles()) {
          return prefixedProp;
        }
      }
      return originalName;
    };
    stylePropPrefix = function(prop) {
      return forEachPrefixes(prop, function(specific, jsPrefix) {
        if (specific in getStyles()) {
          return cssPrefixes[jsPrefix];
        }
      });
    };
    pxExceptions = ["fillOpacity", "columnCount", "flexGrow", "flexShrink", "fontWeight", "lineHeight", "opacity", "zIndex", "zoom"];
    normalizeStyleProp = function(prop, value) {
      if (isNumeric(value) && -1 === pxExceptions.indexOf(prop)) {
        value += "px";
      }
      return value;
    };
    setDimensionProperty = function(elements, propertyName, value) {
      if (elements) {
        value = isNumeric(value) ? value += "px" : value;
        for (let i = 0; i < elements.length; ++i) {
          elements[i].style[propertyName] = value;
        }
      }
    };
    setWidth = function(elements, value) {
      setDimensionProperty(elements, "width", value);
    };
    setHeight = function(elements, value) {
      setDimensionProperty(elements, "height", value);
    };
    setStyle = function(element, styleString) {
      let resetStyle = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : true;
      if (resetStyle) {
        const styleList = [].slice.call(element.style);
        styleList.forEach((propertyName) => {
          element.style.removeProperty(propertyName);
        });
      }
      styleString.split(";").forEach((style) => {
        const parts = style.split(":").map((stylePart) => stylePart.trim());
        if (2 === parts.length) {
          const [property, value] = parts;
          element.style[property] = value;
        }
      });
    };
  }
});

// node_modules/devextreme/esm/core/utils/size.js
function getComponentThickness(elem, dimension, component, styles) {
  const get = (elem2, styles2, field) => parseFloat(getCSSProperty(elem2, styles2, field, "0")) || 0;
  const suffix = "border" === component ? "-width" : "";
  return get(elem, styles, `${component}-${dimensionComponents[dimension][0]}${suffix}`) + get(elem, styles, `${component}-${dimensionComponents[dimension][1]}${suffix}`);
}
function elementSizeHelper(sizeProperty, el, value) {
  return 2 === arguments.length ? elementSize(el, sizeProperty) : elementSize(el, sizeProperty, value);
}
var window2, SPECIAL_HEIGHT_VALUES, getSizeByStyles, getElementBoxParams, getElementComputedStyle, getCSSProperty, boxIndices, dimensionComponents, getSize, getContainerHeight, parseHeight, getHeightWithOffset, addOffsetToMaxHeight, addOffsetToMinHeight, getVerticalOffsets, getVisibleHeight, implementationsMap, getWidth, setWidth2, getHeight, setHeight2, getOuterWidth, setOuterWidth, getOuterHeight, setOuterHeight, getInnerWidth, getInnerHeight, elementSize, getWindowByElement, getOffset;
var init_size = __esm({
  "node_modules/devextreme/esm/core/utils/size.js"() {
    init_window();
    init_dom_adapter();
    init_type();
    window2 = getWindow();
    SPECIAL_HEIGHT_VALUES = ["auto", "none", "inherit", "initial"];
    getSizeByStyles = function(elementStyles, styles) {
      let result = 0;
      styles.forEach(function(style) {
        result += parseFloat(elementStyles[style]) || 0;
      });
      return result;
    };
    getElementBoxParams = function(name, elementStyles) {
      const beforeName = "width" === name ? "Left" : "Top";
      const afterName = "width" === name ? "Right" : "Bottom";
      return {
        padding: getSizeByStyles(elementStyles, ["padding" + beforeName, "padding" + afterName]),
        border: getSizeByStyles(elementStyles, ["border" + beforeName + "Width", "border" + afterName + "Width"]),
        margin: getSizeByStyles(elementStyles, ["margin" + beforeName, "margin" + afterName])
      };
    };
    getElementComputedStyle = function(element) {
      var _element$ownerDocumen;
      const view = (null === element || void 0 === element || null === (_element$ownerDocumen = element.ownerDocument) || void 0 === _element$ownerDocumen ? void 0 : _element$ownerDocumen.defaultView) || window2;
      return view.getComputedStyle && view.getComputedStyle(element);
    };
    getCSSProperty = function(element, styles, name, defaultValue) {
      var _element$style;
      return (null === styles || void 0 === styles ? void 0 : styles[name]) || (null === (_element$style = element.style) || void 0 === _element$style ? void 0 : _element$style[name]) || defaultValue;
    };
    boxIndices = {
      content: 0,
      padding: 1,
      border: 2,
      margin: 3,
      "content-box": 0,
      "border-box": 2
    };
    dimensionComponents = {
      width: ["left", "right"],
      height: ["top", "bottom"]
    };
    getSize = function(element, dimension, box) {
      const offsetFieldName = "width" === dimension ? "offsetWidth" : "offsetHeight";
      const styles = getElementComputedStyle(element);
      let result = getCSSProperty(element, styles, dimension);
      if ("" === result || "auto" === result) {
        result = element[offsetFieldName];
      }
      result = parseFloat(result) || 0;
      const currentBox = getCSSProperty(element, styles, "boxSizing", "content-box");
      const targetBox = box || currentBox;
      let targetBoxIndex = boxIndices[targetBox];
      let currentBoxIndex = boxIndices[currentBox];
      if (void 0 === targetBoxIndex || void 0 === currentBoxIndex) {
        throw new Error();
      }
      if (currentBoxIndex === targetBoxIndex) {
        return result;
      }
      const coeff = Math.sign(targetBoxIndex - currentBoxIndex);
      let padding = false;
      let border = false;
      let margin = false;
      let scrollThickness = false;
      if (1 === coeff) {
        targetBoxIndex += 1;
        currentBoxIndex += 1;
      }
      for (let boxPart = currentBoxIndex; boxPart !== targetBoxIndex; boxPart += coeff) {
        switch (boxPart) {
          case boxIndices.content:
            break;
          case boxIndices.padding:
            padding = coeff * getComponentThickness(element, dimension, "padding", styles);
            break;
          case boxIndices.border:
            border = coeff * getComponentThickness(element, dimension, "border", styles);
            break;
          case boxIndices.margin:
            margin = coeff * getComponentThickness(element, dimension, "margin", styles);
        }
      }
      if (padding || border) {
        const paddingAndBorder = (false === padding ? coeff * getComponentThickness(element, dimension, "padding", styles) : padding) + (false === border ? coeff * getComponentThickness(element, dimension, "border", styles) : border);
        scrollThickness = coeff * Math.max(0, Math.floor(element[offsetFieldName] - result - coeff * paddingAndBorder)) || 0;
      }
      return result + margin + padding + border + scrollThickness;
    };
    getContainerHeight = function(container) {
      return isWindow(container) ? container.innerHeight : container.offsetHeight;
    };
    parseHeight = function(value, container, element) {
      if (value.indexOf("px") > 0) {
        value = parseInt(value.replace("px", ""));
      } else if (value.indexOf("%") > 0) {
        value = parseInt(value.replace("%", "")) * getContainerHeight(container) / 100;
      } else if (!isNaN(value)) {
        value = parseInt(value);
      } else if (value.indexOf("vh") > 0) {
        value = window2.innerHeight / 100 * parseInt(value.replace("vh", ""));
      } else if (element && value.indexOf("em") > 0) {
        value = parseFloat(value.replace("em", "")) * parseFloat(window2.getComputedStyle(element).fontSize);
      }
      return value;
    };
    getHeightWithOffset = function(value, offset, container) {
      if (!value) {
        return null;
      }
      if (SPECIAL_HEIGHT_VALUES.indexOf(value) > -1) {
        return offset ? null : value;
      }
      if (isString(value)) {
        value = parseHeight(value, container);
      }
      if (isNumeric(value)) {
        return Math.max(0, value + offset);
      }
      const operationString = offset < 0 ? " - " : " ";
      return "calc(" + value + operationString + Math.abs(offset) + "px)";
    };
    addOffsetToMaxHeight = function(value, offset, container) {
      const maxHeight = getHeightWithOffset(value, offset, container);
      return null !== maxHeight ? maxHeight : "none";
    };
    addOffsetToMinHeight = function(value, offset, container) {
      const minHeight = getHeightWithOffset(value, offset, container);
      return null !== minHeight ? minHeight : 0;
    };
    getVerticalOffsets = function(element, withMargins) {
      if (!element) {
        return 0;
      }
      const boxParams = getElementBoxParams("height", window2.getComputedStyle(element));
      return boxParams.padding + boxParams.border + (withMargins ? boxParams.margin : 0);
    };
    getVisibleHeight = function(element) {
      if (element) {
        var _element$getBoundingC;
        const boundingClientRect = null === (_element$getBoundingC = element.getBoundingClientRect) || void 0 === _element$getBoundingC ? void 0 : _element$getBoundingC.call(element);
        if (null !== boundingClientRect && void 0 !== boundingClientRect && boundingClientRect.height) {
          return boundingClientRect.height;
        }
      }
      return 0;
    };
    implementationsMap = {
      getWidth: function() {
        for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }
        return elementSizeHelper("width", ...args);
      },
      setWidth: function() {
        for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          args[_key2] = arguments[_key2];
        }
        return elementSizeHelper("width", ...args);
      },
      getHeight: function() {
        for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
          args[_key3] = arguments[_key3];
        }
        return elementSizeHelper("height", ...args);
      },
      setHeight: function() {
        for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
          args[_key4] = arguments[_key4];
        }
        return elementSizeHelper("height", ...args);
      },
      getOuterWidth: function() {
        for (var _len5 = arguments.length, args = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
          args[_key5] = arguments[_key5];
        }
        return elementSizeHelper("outerWidth", ...args);
      },
      setOuterWidth: function() {
        for (var _len6 = arguments.length, args = new Array(_len6), _key6 = 0; _key6 < _len6; _key6++) {
          args[_key6] = arguments[_key6];
        }
        return elementSizeHelper("outerWidth", ...args);
      },
      getOuterHeight: function() {
        for (var _len7 = arguments.length, args = new Array(_len7), _key7 = 0; _key7 < _len7; _key7++) {
          args[_key7] = arguments[_key7];
        }
        return elementSizeHelper("outerHeight", ...args);
      },
      setOuterHeight: function() {
        for (var _len8 = arguments.length, args = new Array(_len8), _key8 = 0; _key8 < _len8; _key8++) {
          args[_key8] = arguments[_key8];
        }
        return elementSizeHelper("outerHeight", ...args);
      },
      getInnerWidth: function() {
        for (var _len9 = arguments.length, args = new Array(_len9), _key9 = 0; _key9 < _len9; _key9++) {
          args[_key9] = arguments[_key9];
        }
        return elementSizeHelper("innerWidth", ...args);
      },
      setInnerWidth: function() {
        for (var _len10 = arguments.length, args = new Array(_len10), _key10 = 0; _key10 < _len10; _key10++) {
          args[_key10] = arguments[_key10];
        }
        return elementSizeHelper("innerWidth", ...args);
      },
      getInnerHeight: function() {
        for (var _len11 = arguments.length, args = new Array(_len11), _key11 = 0; _key11 < _len11; _key11++) {
          args[_key11] = arguments[_key11];
        }
        return elementSizeHelper("innerHeight", ...args);
      },
      setInnerHeight: function() {
        for (var _len12 = arguments.length, args = new Array(_len12), _key12 = 0; _key12 < _len12; _key12++) {
          args[_key12] = arguments[_key12];
        }
        return elementSizeHelper("innerHeight", ...args);
      }
    };
    getWidth = (el) => implementationsMap.getWidth(el);
    setWidth2 = (el, value) => implementationsMap.setWidth(el, value);
    getHeight = (el) => implementationsMap.getHeight(el);
    setHeight2 = (el, value) => implementationsMap.setHeight(el, value);
    getOuterWidth = (el, includeMargin) => implementationsMap.getOuterWidth(el, includeMargin || false);
    setOuterWidth = (el, value) => implementationsMap.setOuterWidth(el, value);
    getOuterHeight = (el, includeMargin) => implementationsMap.getOuterHeight(el, includeMargin || false);
    setOuterHeight = (el, value) => implementationsMap.setOuterHeight(el, value);
    getInnerWidth = (el) => implementationsMap.getInnerWidth(el);
    getInnerHeight = (el) => implementationsMap.getInnerHeight(el);
    elementSize = function(el, sizeProperty, value) {
      const partialName = sizeProperty.toLowerCase().indexOf("width") >= 0 ? "Width" : "Height";
      const propName = partialName.toLowerCase();
      const isOuter = 0 === sizeProperty.indexOf("outer");
      const isInner = 0 === sizeProperty.indexOf("inner");
      const isGetter = 2 === arguments.length || "boolean" === typeof value;
      if (isRenderer(el)) {
        if (el.length > 1 && !isGetter) {
          for (let i = 0; i < el.length; i++) {
            elementSize(el[i], sizeProperty, value);
          }
          return;
        }
        el = el[0];
      }
      if (!el) {
        return;
      }
      if (isWindow(el)) {
        return isOuter ? el["inner" + partialName] : dom_adapter_default.getDocumentElement()["client" + partialName];
      }
      if (dom_adapter_default.isDocument(el)) {
        const documentElement = dom_adapter_default.getDocumentElement();
        const body = dom_adapter_default.getBody();
        return Math.max(body["scroll" + partialName], body["offset" + partialName], documentElement["scroll" + partialName], documentElement["offset" + partialName], documentElement["client" + partialName]);
      }
      if (isGetter) {
        let box = "content";
        if (isOuter) {
          box = value ? "margin" : "border";
        }
        if (isInner) {
          box = "padding";
        }
        return getSize(el, propName, box);
      }
      if (isNumeric(value)) {
        const elementStyles = getElementComputedStyle(el);
        const sizeAdjustment = getElementBoxParams(propName, elementStyles);
        const isBorderBox = "border-box" === elementStyles.boxSizing;
        value = Number(value);
        if (isOuter) {
          value -= isBorderBox ? 0 : sizeAdjustment.border + sizeAdjustment.padding;
        } else if (isInner) {
          value += isBorderBox ? sizeAdjustment.border : -sizeAdjustment.padding;
        } else if (isBorderBox) {
          value += sizeAdjustment.border + sizeAdjustment.padding;
        }
      }
      value += isNumeric(value) ? "px" : "";
      dom_adapter_default.setStyle(el, propName, value);
      return null;
    };
    getWindowByElement = (el) => isWindow(el) ? el : el.defaultView;
    getOffset = (el) => {
      var _el$getClientRects, _el$getBoundingClient;
      if (!(null !== (_el$getClientRects = el.getClientRects) && void 0 !== _el$getClientRects && _el$getClientRects.call(el).length)) {
        return {
          top: 0,
          left: 0
        };
      }
      const rect = null === (_el$getBoundingClient = el.getBoundingClientRect) || void 0 === _el$getBoundingClient ? void 0 : _el$getBoundingClient.call(el);
      const win = getWindowByElement(el.ownerDocument);
      const docElem = el.ownerDocument.documentElement;
      return {
        top: rect.top + win.pageYOffset - docElem.clientTop,
        left: rect.left + win.pageXOffset - docElem.clientLeft
      };
    };
  }
});

// node_modules/devextreme/esm/core/utils/html_parser.js
var isTagName, tagWrappers, parseHTML, isTablePart;
var init_html_parser = __esm({
  "node_modules/devextreme/esm/core/utils/html_parser.js"() {
    init_dom_adapter();
    isTagName = /<([a-z][^/\0>\x20\t\r\n\f]+)/i;
    tagWrappers = {
      default: {
        tagsCount: 0,
        startTags: "",
        endTags: ""
      },
      thead: {
        tagsCount: 1,
        startTags: "<table>",
        endTags: "</table>"
      },
      td: {
        tagsCount: 3,
        startTags: "<table><tbody><tr>",
        endTags: "</tr></tbody></table>"
      },
      col: {
        tagsCount: 2,
        startTags: "<table><colgroup>",
        endTags: "</colgroup></table>"
      },
      tr: {
        tagsCount: 2,
        startTags: "<table><tbody>",
        endTags: "</tbody></table>"
      }
    };
    tagWrappers.tbody = tagWrappers.colgroup = tagWrappers.caption = tagWrappers.tfoot = tagWrappers.thead;
    tagWrappers.th = tagWrappers.td;
    parseHTML = function(html) {
      if ("string" !== typeof html) {
        return null;
      }
      const fragment = dom_adapter_default.createDocumentFragment();
      let container = fragment.appendChild(dom_adapter_default.createElement("div"));
      const tags = isTagName.exec(html);
      const firstRootTag = tags && tags[1].toLowerCase();
      const tagWrapper = tagWrappers[firstRootTag] || tagWrappers.default;
      container.innerHTML = tagWrapper.startTags + html + tagWrapper.endTags;
      for (let i = 0; i < tagWrapper.tagsCount; i++) {
        container = container.lastChild;
      }
      return [...container.childNodes];
    };
    isTablePart = function(html) {
      const tags = isTagName.exec(html);
      return tags && tags[1] in tagWrappers;
    };
  }
});

// node_modules/devextreme/esm/core/renderer_base.js
var window3, renderer, initRender, repeatMethod, setAttributeValue, appendElements, setCss, isVisible, emptyArray, rendererWrapper, renderer_base_default;
var init_renderer_base = __esm({
  "node_modules/devextreme/esm/core/renderer_base.js"() {
    init_element_data();
    init_dom_adapter();
    init_window();
    init_type();
    init_style();
    init_size();
    init_html_parser();
    window3 = getWindow();
    initRender = function(selector, context) {
      if (!selector) {
        this.length = 0;
        return this;
      }
      if ("string" === typeof selector) {
        if ("body" === selector) {
          this[0] = context ? context.body : dom_adapter_default.getBody();
          this.length = 1;
          return this;
        }
        context = context || dom_adapter_default.getDocument();
        if ("<" === selector[0]) {
          this[0] = dom_adapter_default.createElement(selector.slice(1, -1), context);
          this.length = 1;
          return this;
        }
        [].push.apply(this, dom_adapter_default.querySelectorAll(context, selector));
        return this;
      } else if (dom_adapter_default.isNode(selector) || isWindow(selector)) {
        this[0] = selector;
        this.length = 1;
        return this;
      } else if (Array.isArray(selector)) {
        [].push.apply(this, selector);
        return this;
      }
      return renderer(selector.toArray ? selector.toArray() : [selector]);
    };
    renderer = function(selector, context) {
      return new initRender(selector, context);
    };
    renderer.fn = {
      dxRenderer: true
    };
    initRender.prototype = renderer.fn;
    repeatMethod = function(methodName, args) {
      for (let i = 0; i < this.length; i++) {
        const item = renderer(this[i]);
        item[methodName].apply(item, args);
      }
      return this;
    };
    setAttributeValue = function(element, attrName, value) {
      if (void 0 !== value && null !== value && false !== value) {
        dom_adapter_default.setAttribute(element, attrName, value);
      } else {
        dom_adapter_default.removeAttribute(element, attrName);
      }
    };
    initRender.prototype.show = function() {
      return this.toggle(true);
    };
    initRender.prototype.hide = function() {
      return this.toggle(false);
    };
    initRender.prototype.toggle = function(value) {
      if (this[0]) {
        this.toggleClass("dx-state-invisible", !value);
      }
      return this;
    };
    initRender.prototype.attr = function(attrName, value) {
      if (this.length > 1 && arguments.length > 1) {
        return repeatMethod.call(this, "attr", arguments);
      }
      if (!this[0]) {
        if (isObject(attrName) || void 0 !== value) {
          return this;
        } else {
          return;
        }
      }
      if (!this[0].getAttribute) {
        return this.prop(attrName, value);
      }
      if ("string" === typeof attrName && 1 === arguments.length) {
        const result = this[0].getAttribute(attrName);
        return null == result ? void 0 : result;
      } else if (isPlainObject(attrName)) {
        for (const key in attrName) {
          this.attr(key, attrName[key]);
        }
      } else {
        setAttributeValue(this[0], attrName, value);
      }
      return this;
    };
    initRender.prototype.removeAttr = function(attrName) {
      this[0] && dom_adapter_default.removeAttribute(this[0], attrName);
      return this;
    };
    initRender.prototype.prop = function(propName, value) {
      if (!this[0]) {
        return this;
      }
      if ("string" === typeof propName && 1 === arguments.length) {
        return this[0][propName];
      } else if (isPlainObject(propName)) {
        for (const key in propName) {
          this.prop(key, propName[key]);
        }
      } else {
        dom_adapter_default.setProperty(this[0], propName, value);
      }
      return this;
    };
    initRender.prototype.addClass = function(className) {
      return this.toggleClass(className, true);
    };
    initRender.prototype.removeClass = function(className) {
      return this.toggleClass(className, false);
    };
    initRender.prototype.hasClass = function(className) {
      if (!this[0] || void 0 === this[0].className) {
        return false;
      }
      const classNames = className.split(" ");
      for (let i = 0; i < classNames.length; i++) {
        if (this[0].classList) {
          if (this[0].classList.contains(classNames[i])) {
            return true;
          }
        } else {
          const className2 = isString(this[0].className) ? this[0].className : dom_adapter_default.getAttribute(this[0], "class");
          if ((className2 || "").split(" ").indexOf(classNames[i]) >= 0) {
            return true;
          }
        }
      }
      return false;
    };
    initRender.prototype.toggleClass = function(className, value) {
      if (this.length > 1) {
        return repeatMethod.call(this, "toggleClass", arguments);
      }
      if (!this[0] || !className) {
        return this;
      }
      value = void 0 === value ? !this.hasClass(className) : value;
      const classNames = className.split(" ");
      for (let i = 0; i < classNames.length; i++) {
        dom_adapter_default.setClass(this[0], classNames[i], value);
      }
      return this;
    };
    initRender.prototype.html = function(value) {
      if (!arguments.length) {
        return this[0].innerHTML;
      }
      this.empty();
      if ("string" === typeof value && !isTablePart(value) || "number" === typeof value) {
        this[0].innerHTML = value;
        return this;
      }
      return this.append(parseHTML(value));
    };
    appendElements = function(element, nextSibling) {
      if (!this[0] || !element) {
        return;
      }
      if ("string" === typeof element) {
        element = parseHTML(element);
      } else if (element.nodeType) {
        element = [element];
      } else if (isNumeric(element)) {
        element = [dom_adapter_default.createTextNode(element)];
      }
      for (let i = 0; i < element.length; i++) {
        const item = element[i];
        let container = this[0];
        const wrapTR = "TABLE" === container.tagName && "TR" === item.tagName;
        if (wrapTR && container.tBodies && container.tBodies.length) {
          container = container.tBodies[0];
        }
        dom_adapter_default.insertElement(container, item.nodeType ? item : item[0], nextSibling);
      }
    };
    setCss = function(name, value) {
      if (!this[0] || !this[0].style) {
        return;
      }
      if (null === value || "number" === typeof value && isNaN(value)) {
        return;
      }
      name = styleProp(name);
      for (let i = 0; i < this.length; i++) {
        this[i].style[name] = normalizeStyleProp(name, value);
      }
    };
    initRender.prototype.css = function(name, value) {
      if (isString(name)) {
        if (2 === arguments.length) {
          setCss.call(this, name, value);
        } else {
          if (!this[0]) {
            return;
          }
          name = styleProp(name);
          const result = window3.getComputedStyle(this[0])[name] || this[0].style[name];
          return isNumeric(result) ? result.toString() : result;
        }
      } else if (isPlainObject(name)) {
        for (const key in name) {
          setCss.call(this, key, name[key]);
        }
      }
      return this;
    };
    initRender.prototype.prepend = function(element) {
      if (arguments.length > 1) {
        for (let i = 0; i < arguments.length; i++) {
          this.prepend(arguments[i]);
        }
        return this;
      }
      appendElements.apply(this, [element, this[0].firstChild]);
      return this;
    };
    initRender.prototype.append = function(element) {
      if (arguments.length > 1) {
        for (let i = 0; i < arguments.length; i++) {
          this.append(arguments[i]);
        }
        return this;
      }
      appendElements.apply(this, [element]);
      return this;
    };
    initRender.prototype.prependTo = function(element) {
      if (this.length > 1) {
        for (let i = this.length - 1; i >= 0; i--) {
          renderer(this[i]).prependTo(element);
        }
        return this;
      }
      element = renderer(element);
      if (element[0]) {
        dom_adapter_default.insertElement(element[0], this[0], element[0].firstChild);
      }
      return this;
    };
    initRender.prototype.appendTo = function(element) {
      if (this.length > 1) {
        return repeatMethod.call(this, "appendTo", arguments);
      }
      dom_adapter_default.insertElement(renderer(element)[0], this[0]);
      return this;
    };
    initRender.prototype.insertBefore = function(element) {
      if (element && element[0]) {
        dom_adapter_default.insertElement(element[0].parentNode, this[0], element[0]);
      }
      return this;
    };
    initRender.prototype.insertAfter = function(element) {
      if (element && element[0]) {
        dom_adapter_default.insertElement(element[0].parentNode, this[0], element[0].nextSibling);
      }
      return this;
    };
    initRender.prototype.before = function(element) {
      if (this[0]) {
        dom_adapter_default.insertElement(this[0].parentNode, element[0], this[0]);
      }
      return this;
    };
    initRender.prototype.after = function(element) {
      if (this[0]) {
        dom_adapter_default.insertElement(this[0].parentNode, element[0], this[0].nextSibling);
      }
      return this;
    };
    initRender.prototype.wrap = function(wrapper) {
      if (this[0]) {
        const wrap = renderer(wrapper);
        wrap.insertBefore(this);
        wrap.append(this);
      }
      return this;
    };
    initRender.prototype.wrapInner = function(wrapper) {
      const contents = this.contents();
      if (contents.length) {
        contents.wrap(wrapper);
      } else {
        this.append(wrapper);
      }
      return this;
    };
    initRender.prototype.replaceWith = function(element) {
      if (!(element && element[0])) {
        return;
      }
      if (element.is(this)) {
        return this;
      }
      element.insertBefore(this);
      this.remove();
      return element;
    };
    initRender.prototype.remove = function() {
      if (this.length > 1) {
        return repeatMethod.call(this, "remove", arguments);
      }
      cleanDataRecursive(this[0], true);
      dom_adapter_default.removeElement(this[0]);
      return this;
    };
    initRender.prototype.detach = function() {
      if (this.length > 1) {
        return repeatMethod.call(this, "detach", arguments);
      }
      dom_adapter_default.removeElement(this[0]);
      return this;
    };
    initRender.prototype.empty = function() {
      if (this.length > 1) {
        return repeatMethod.call(this, "empty", arguments);
      }
      cleanDataRecursive(this[0]);
      dom_adapter_default.setText(this[0], "");
      return this;
    };
    initRender.prototype.clone = function() {
      const result = [];
      for (let i = 0; i < this.length; i++) {
        result.push(this[i].cloneNode(true));
      }
      return renderer(result);
    };
    initRender.prototype.text = function(value) {
      if (!arguments.length) {
        let result = "";
        for (let i = 0; i < this.length; i++) {
          result += this[i] && this[i].textContent || "";
        }
        return result;
      }
      const text = isFunction(value) ? value() : value;
      cleanDataRecursive(this[0], false);
      dom_adapter_default.setText(this[0], isDefined(text) ? text : "");
      return this;
    };
    initRender.prototype.val = function(value) {
      if (1 === arguments.length) {
        return this.prop("value", isDefined(value) ? value : "");
      }
      return this.prop("value");
    };
    initRender.prototype.contents = function() {
      if (!this[0]) {
        return renderer();
      }
      const result = [];
      result.push.apply(result, this[0].childNodes);
      return renderer(result);
    };
    initRender.prototype.find = function(selector) {
      const result = renderer();
      if (!selector) {
        return result;
      }
      const nodes = [];
      let i;
      if ("string" === typeof selector) {
        selector = selector.trim();
        for (i = 0; i < this.length; i++) {
          const element = this[i];
          if (dom_adapter_default.isElementNode(element)) {
            const elementId = element.getAttribute("id");
            let queryId = elementId || "dx-query-children";
            if (!elementId) {
              setAttributeValue(element, "id", queryId);
            }
            queryId = "[id='" + queryId + "'] ";
            const querySelector = queryId + selector.replace(/([^\\])(,)/g, "$1, " + queryId);
            nodes.push.apply(nodes, dom_adapter_default.querySelectorAll(element, querySelector));
            setAttributeValue(element, "id", elementId);
          } else if (dom_adapter_default.isDocument(element) || dom_adapter_default.isDocumentFragment(element)) {
            nodes.push.apply(nodes, dom_adapter_default.querySelectorAll(element, selector));
          }
        }
      } else {
        for (i = 0; i < this.length; i++) {
          selector = dom_adapter_default.isNode(selector) ? selector : selector[0];
          if (this[i] !== selector && this[i].contains(selector)) {
            nodes.push(selector);
          }
        }
      }
      return result.add(nodes);
    };
    isVisible = function(_, element) {
      var _element$getClientRec, _element;
      element = element.host ?? element;
      if (!element.nodeType) {
        return true;
      }
      return !!(element.offsetWidth || element.offsetHeight || null !== (_element$getClientRec = (_element = element).getClientRects) && void 0 !== _element$getClientRec && _element$getClientRec.call(_element).length);
    };
    initRender.prototype.filter = function(selector) {
      if (!selector) {
        return renderer();
      }
      if (":visible" === selector) {
        return this.filter(isVisible);
      } else if (":hidden" === selector) {
        return this.filter(function(_, element) {
          return !isVisible(0, element);
        });
      }
      const result = [];
      for (let i = 0; i < this.length; i++) {
        const item = this[i];
        if (dom_adapter_default.isElementNode(item) && "string" === type(selector)) {
          dom_adapter_default.elementMatches(item, selector) && result.push(item);
        } else if (dom_adapter_default.isNode(selector) || isWindow(selector)) {
          selector === item && result.push(item);
        } else if (isFunction(selector)) {
          selector.call(item, i, item) && result.push(item);
        } else {
          for (let j = 0; j < selector.length; j++) {
            selector[j] === item && result.push(item);
          }
        }
      }
      return renderer(result);
    };
    initRender.prototype.not = function(selector) {
      const result = [];
      const nodes = this.filter(selector).toArray();
      for (let i = 0; i < this.length; i++) {
        if (-1 === nodes.indexOf(this[i])) {
          result.push(this[i]);
        }
      }
      return renderer(result);
    };
    initRender.prototype.is = function(selector) {
      return !!this.filter(selector).length;
    };
    initRender.prototype.children = function(selector) {
      let result = [];
      for (let i = 0; i < this.length; i++) {
        const nodes = this[i] ? this[i].childNodes : [];
        for (let j = 0; j < nodes.length; j++) {
          if (dom_adapter_default.isElementNode(nodes[j])) {
            result.push(nodes[j]);
          }
        }
      }
      result = renderer(result);
      return selector ? result.filter(selector) : result;
    };
    initRender.prototype.siblings = function() {
      const element = this[0];
      if (!element || !element.parentNode) {
        return renderer();
      }
      const result = [];
      const parentChildNodes = element.parentNode.childNodes || [];
      for (let i = 0; i < parentChildNodes.length; i++) {
        const node = parentChildNodes[i];
        if (dom_adapter_default.isElementNode(node) && node !== element) {
          result.push(node);
        }
      }
      return renderer(result);
    };
    initRender.prototype.each = function(callback) {
      for (let i = 0; i < this.length; i++) {
        if (false === callback.call(this[i], i, this[i])) {
          break;
        }
      }
    };
    initRender.prototype.index = function(element) {
      if (!element) {
        return this.parent().children().index(this);
      }
      element = renderer(element);
      return this.toArray().indexOf(element[0]);
    };
    initRender.prototype.get = function(index) {
      return this[index < 0 ? this.length + index : index];
    };
    initRender.prototype.eq = function(index) {
      index = index < 0 ? this.length + index : index;
      return renderer(this[index]);
    };
    initRender.prototype.first = function() {
      return this.eq(0);
    };
    initRender.prototype.last = function() {
      return this.eq(-1);
    };
    initRender.prototype.select = function() {
      for (let i = 0; i < this.length; i += 1) {
        this[i].select && this[i].select();
      }
      return this;
    };
    initRender.prototype.parent = function(selector) {
      if (!this[0]) {
        return renderer();
      }
      const result = renderer(this[0].parentNode);
      return !selector || result.is(selector) ? result : renderer();
    };
    initRender.prototype.parents = function(selector) {
      const result = [];
      let parent = this.parent();
      while (parent && parent[0] && !dom_adapter_default.isDocument(parent[0])) {
        if (dom_adapter_default.isElementNode(parent[0])) {
          if (!selector || parent.is(selector)) {
            result.push(parent.get(0));
          }
        }
        parent = parent.parent();
      }
      return renderer(result);
    };
    initRender.prototype.closest = function(selector) {
      if (this.is(selector)) {
        return this;
      }
      let parent = this.parent();
      while (parent && parent.length) {
        if (parent.is(selector)) {
          return parent;
        }
        parent = parent.parent();
      }
      return renderer();
    };
    initRender.prototype.next = function(selector) {
      if (!this[0]) {
        return renderer();
      }
      let next = renderer(this[0].nextSibling);
      if (!arguments.length) {
        return next;
      }
      while (next && next.length) {
        if (next.is(selector)) {
          return next;
        }
        next = next.next();
      }
      return renderer();
    };
    initRender.prototype.prev = function() {
      if (!this[0]) {
        return renderer();
      }
      return renderer(this[0].previousSibling);
    };
    initRender.prototype.add = function(selector) {
      const targets = renderer(selector);
      const result = this.toArray();
      for (let i = 0; i < targets.length; i++) {
        const target = targets[i];
        if (-1 === result.indexOf(target)) {
          result.push(target);
        }
      }
      return renderer(result);
    };
    emptyArray = [];
    initRender.prototype.splice = function() {
      return renderer(emptyArray.splice.apply(this, arguments));
    };
    initRender.prototype.slice = function() {
      return renderer(emptyArray.slice.apply(this, arguments));
    };
    initRender.prototype.toArray = function() {
      return emptyArray.slice.call(this);
    };
    initRender.prototype.offset = function() {
      if (!this[0]) {
        return;
      }
      return getOffset(this[0]);
    };
    initRender.prototype.offsetParent = function() {
      if (!this[0]) {
        return renderer();
      }
      let offsetParent = renderer(this[0].offsetParent);
      while (offsetParent[0] && "static" === offsetParent.css("position")) {
        offsetParent = renderer(offsetParent[0].offsetParent);
      }
      offsetParent = offsetParent[0] ? offsetParent : renderer(dom_adapter_default.getDocumentElement());
      return offsetParent;
    };
    initRender.prototype.position = function() {
      if (!this[0]) {
        return;
      }
      let offset;
      const marginTop = parseFloat(this.css("marginTop"));
      const marginLeft = parseFloat(this.css("marginLeft"));
      if ("fixed" === this.css("position")) {
        offset = this[0].getBoundingClientRect();
        return {
          top: offset.top - marginTop,
          left: offset.left - marginLeft
        };
      }
      offset = this.offset();
      const offsetParent = this.offsetParent();
      let parentOffset = {
        top: 0,
        left: 0
      };
      if ("HTML" !== offsetParent[0].nodeName) {
        parentOffset = offsetParent.offset();
      }
      parentOffset = {
        top: parentOffset.top + parseFloat(offsetParent.css("borderTopWidth")),
        left: parentOffset.left + parseFloat(offsetParent.css("borderLeftWidth"))
      };
      return {
        top: offset.top - parentOffset.top - marginTop,
        left: offset.left - parentOffset.left - marginLeft
      };
    };
    [{
      name: "scrollLeft",
      offsetProp: "pageXOffset",
      scrollWindow: function(win, value) {
        win.scrollTo(value, win.pageYOffset);
      }
    }, {
      name: "scrollTop",
      offsetProp: "pageYOffset",
      scrollWindow: function(win, value) {
        win.scrollTo(win.pageXOffset, value);
      }
    }].forEach(function(directionStrategy) {
      const propName = directionStrategy.name;
      initRender.prototype[propName] = function(value) {
        if (!this[0]) {
          return;
        }
        const window4 = getWindowByElement(this[0]);
        if (void 0 === value) {
          return window4 ? window4[directionStrategy.offsetProp] : this[0][propName];
        }
        if (window4) {
          directionStrategy.scrollWindow(window4, value);
        } else {
          this[0][propName] = value;
        }
        return this;
      };
    });
    initRender.prototype.data = function(key, value) {
      if (!this[0]) {
        return;
      }
      if (arguments.length < 2) {
        return data.call(renderer, this[0], key);
      }
      data.call(renderer, this[0], key, value);
      return this;
    };
    initRender.prototype.removeData = function(key) {
      this[0] && removeData(this[0], key);
      return this;
    };
    rendererWrapper = function() {
      return renderer.apply(this, arguments);
    };
    Object.defineProperty(rendererWrapper, "fn", {
      enumerable: true,
      configurable: true,
      get: function() {
        return renderer.fn;
      },
      set: function(value) {
        renderer.fn = value;
      }
    });
    renderer_base_default = {
      set: function(strategy2) {
        renderer = strategy2;
      },
      get: function() {
        return rendererWrapper;
      }
    };
  }
});

// node_modules/devextreme/esm/core/renderer.js
var renderer_default;
var init_renderer = __esm({
  "node_modules/devextreme/esm/core/renderer.js"() {
    init_renderer_base();
    renderer_default = renderer_base_default.get();
  }
});

export {
  MemorizedCallbacks,
  init_memorized_callbacks,
  event_registrator_callbacks_default,
  init_event_registrator_callbacks,
  getEventTarget,
  init_event_target,
  events_engine_default,
  init_events_engine,
  data,
  beforeCleanData,
  removeData,
  cleanDataRecursive,
  init_element_data,
  dasherize,
  camelize,
  humanize,
  titleize,
  captionize,
  init_inflector,
  styleProp,
  stylePropPrefix,
  normalizeStyleProp,
  setWidth,
  setHeight,
  setStyle,
  init_style,
  getElementBoxParams,
  parseHeight,
  addOffsetToMaxHeight,
  addOffsetToMinHeight,
  getVerticalOffsets,
  getVisibleHeight,
  getWidth,
  setWidth2,
  getHeight,
  setHeight2,
  getOuterWidth,
  setOuterWidth,
  getOuterHeight,
  setOuterHeight,
  getInnerWidth,
  getInnerHeight,
  getOffset,
  init_size,
  parseHTML,
  init_html_parser,
  renderer_default,
  init_renderer
};
//# sourceMappingURL=chunk-KKWCXJXC.js.map
