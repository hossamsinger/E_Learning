import {
  custom_store_exports,
  init_custom_store
} from "./chunk-VVVI3OU6.js";
import "./chunk-KKWCXJXC.js";
import {
  init_utils,
  utils_exports
} from "./chunk-3N2Q5ACA.js";
import {
  ajax_exports,
  deferred_exports,
  init_ajax,
  init_deferred
} from "./chunk-TEJ7FDOJ.js";
import {
  extend_exports,
  init_extend
} from "./chunk-ND5ICVCX.js";
import {
  __commonJS,
  __toCommonJS
} from "./chunk-WOR4A3D2.js";

// node_modules/devextreme-aspnet-data-nojquery/index.js
var require_devextreme_aspnet_data_nojquery = __commonJS({
  "node_modules/devextreme-aspnet-data-nojquery/index.js"(exports, module) {
    (function(factory) {
      "use strict";
      function unwrapESModule(module2) {
        return module2 && module2.__esModule && module2.default ? module2.default : module2;
      }
      if (typeof define === "function" && define.amd) {
        define(function(require2, exports2, module2) {
          module2.exports = factory(unwrapESModule(require2("devextreme/core/utils/ajax")), require2("devextreme/core/utils/deferred").Deferred, require2("devextreme/core/utils/extend").extend, unwrapESModule(require2("devextreme/data/custom_store")), unwrapESModule(require2("devextreme/data/utils")));
        });
      } else if (typeof module === "object" && module.exports) {
        module.exports = factory(unwrapESModule((init_ajax(), __toCommonJS(ajax_exports))), (init_deferred(), __toCommonJS(deferred_exports)).Deferred, (init_extend(), __toCommonJS(extend_exports)).extend, unwrapESModule((init_custom_store(), __toCommonJS(custom_store_exports))), unwrapESModule((init_utils(), __toCommonJS(utils_exports))));
      } else {
        throw "This script should be used with an AMD or CommonJS loader";
      }
    })(function(ajaxUtility, Deferred, extend, CustomStore, dataUtils) {
      "use strict";
      var CUSTOM_STORE_OPTIONS = ["onLoading", "onLoaded", "onInserting", "onInserted", "onUpdating", "onUpdated", "onRemoving", "onRemoved", "onModifying", "onModified", "onPush", "loadMode", "cacheRawData", "errorHandler"];
      function createStoreConfig(options) {
        var keyExpr = options.key, loadUrl = options.loadUrl, loadMethod = options.loadMethod || "GET", loadParams = options.loadParams, isRawLoadMode = options.loadMode === "raw", updateUrl = options.updateUrl, insertUrl = options.insertUrl, deleteUrl = options.deleteUrl, onBeforeSend = options.onBeforeSend, onAjaxError = options.onAjaxError;
        function send(operation, requiresKey, ajaxSettings, customSuccessHandler) {
          var d = Deferred(), thenable, beforeSendResult;
          function sendCore() {
            ajaxUtility.sendRequest(ajaxSettings).then(function(res, textStatus, xhr) {
              if (customSuccessHandler) customSuccessHandler(d, res, xhr);
              else d.resolve();
            }, function(xhr, textStatus) {
              var error = getErrorMessageFromXhr(xhr);
              if (onAjaxError) {
                var e = {
                  xhr,
                  error
                };
                onAjaxError(e);
                error = e.error;
              }
              if (error) d.reject(error);
              else d.reject(xhr, textStatus);
            });
          }
          if (requiresKey && !keyExpr) {
            d.reject(new Error("Primary key is not specified (operation: '" + operation + "', url: '" + ajaxSettings.url + "')"));
          } else {
            if (operation === "load") {
              ajaxSettings.cache = false;
              ajaxSettings.dataType = "json";
            } else {
              ajaxSettings.dataType = "text";
            }
            if (onBeforeSend) {
              beforeSendResult = onBeforeSend(operation, ajaxSettings);
              if (beforeSendResult && typeof beforeSendResult.then === "function") thenable = beforeSendResult;
            }
            if (thenable) thenable.then(sendCore, function(error) {
              d.reject(error);
            });
            else sendCore();
          }
          return d.promise();
        }
        function filterByKey(keyValue) {
          if (!Array.isArray(keyExpr)) return [keyExpr, keyValue];
          return keyExpr.map(function(i) {
            return [i, keyValue[i]];
          });
        }
        function loadOptionsToActionParams(options2, isCountQuery) {
          var result2 = {};
          if (isCountQuery) result2.isCountQuery = isCountQuery;
          if (options2) {
            ["skip", "take", "requireTotalCount", "requireGroupCount"].forEach(function(i) {
              if (options2[i] !== void 0) result2[i] = options2[i];
            });
            var normalizeSorting = dataUtils.normalizeSortingInfo, group = options2.group, filter = options2.filter, select = options2.select;
            if (options2.sort) result2.sort = JSON.stringify(normalizeSorting(options2.sort));
            if (group) {
              if (!isAdvancedGrouping(group)) group = normalizeSorting(group);
              result2.group = JSON.stringify(group);
            }
            if (Array.isArray(filter)) {
              filter = extend(true, [], filter);
              stringifyDatesInFilter(filter);
              result2.filter = JSON.stringify(filter);
            }
            if (options2.totalSummary) result2.totalSummary = JSON.stringify(options2.totalSummary);
            if (options2.groupSummary) result2.groupSummary = JSON.stringify(options2.groupSummary);
            if (select) {
              if (!Array.isArray(select)) select = [select];
              result2.select = JSON.stringify(select);
            }
          }
          extend(result2, loadParams);
          return result2;
        }
        function handleInsertUpdateSuccess(d, res, xhr) {
          var mime = xhr.getResponseHeader("Content-Type"), isJSON = mime && mime.indexOf("application/json") > -1;
          d.resolve(isJSON ? JSON.parse(res) : res);
        }
        var result = {
          key: keyExpr,
          useDefaultSearch: true,
          load: function(loadOptions) {
            return send("load", false, {
              url: loadUrl,
              method: loadMethod,
              data: loadOptionsToActionParams(loadOptions)
            }, function(d, res) {
              processLoadResponse(d, res, function(res2) {
                return [res2.data, createLoadExtra(res2)];
              });
            });
          },
          totalCount: !isRawLoadMode && function(loadOptions) {
            return send("load", false, {
              url: loadUrl,
              method: loadMethod,
              data: loadOptionsToActionParams(loadOptions, true)
            }, function(d, res) {
              processLoadResponse(d, res, function(res2) {
                return [res2.totalCount];
              });
            });
          },
          byKey: !isRawLoadMode && function(key) {
            return send("load", true, {
              url: loadUrl,
              method: loadMethod,
              data: loadOptionsToActionParams({
                filter: filterByKey(key)
              })
            }, function(d, res) {
              processLoadResponse(d, res, function(res2) {
                return [res2.data[0]];
              });
            });
          },
          update: updateUrl && function(key, values) {
            return send("update", true, {
              url: updateUrl,
              method: options.updateMethod || "PUT",
              data: {
                key: serializeKey(key),
                values: JSON.stringify(values)
              }
            }, handleInsertUpdateSuccess);
          },
          insert: insertUrl && function(values) {
            return send("insert", true, {
              url: insertUrl,
              method: options.insertMethod || "POST",
              data: {
                values: JSON.stringify(values)
              }
            }, handleInsertUpdateSuccess);
          },
          remove: deleteUrl && function(key) {
            return send("delete", true, {
              url: deleteUrl,
              method: options.deleteMethod || "DELETE",
              data: {
                key: serializeKey(key)
              }
            });
          }
        };
        CUSTOM_STORE_OPTIONS.forEach(function(name) {
          var value = options[name];
          if (value !== void 0) result[name] = value;
        });
        return result;
      }
      function processLoadResponse(d, res, getResolveArgs) {
        res = expandLoadResponse(res);
        if (!res || typeof res !== "object") d.reject(new Error("Unexpected response received"));
        else d.resolve.apply(d, getResolveArgs(res));
      }
      function expandLoadResponse(value) {
        if (Array.isArray(value)) return {
          data: value
        };
        if (typeof value === "number") return {
          totalCount: value
        };
        return value;
      }
      function createLoadExtra(res) {
        return {
          totalCount: "totalCount" in res ? res.totalCount : -1,
          groupCount: "groupCount" in res ? res.groupCount : -1,
          summary: res.summary || null
        };
      }
      function serializeKey(key) {
        if (typeof key === "object") return JSON.stringify(key);
        return key;
      }
      function serializeDate(date) {
        function zpad(text, len) {
          text = String(text);
          while (text.length < len) text = "0" + text;
          return text;
        }
        var builder = [1 + date.getMonth(), "/", date.getDate(), "/", date.getFullYear()], h = date.getHours(), m = date.getMinutes(), s = date.getSeconds(), f = date.getMilliseconds();
        if (h + m + s + f > 0) builder.push(" ", zpad(h, 2), ":", zpad(m, 2), ":", zpad(s, 2), ".", zpad(f, 3));
        return builder.join("");
      }
      function stringifyDatesInFilter(crit) {
        crit.forEach(function(v, k) {
          if (Array.isArray(v)) {
            stringifyDatesInFilter(v);
          } else if (Object.prototype.toString.call(v) === "[object Date]") {
            crit[k] = serializeDate(v);
          }
        });
      }
      function isAdvancedGrouping(expr) {
        if (!Array.isArray(expr)) return false;
        for (var i = 0; i < expr.length; i++) {
          if ("groupInterval" in expr[i] || "isExpanded" in expr[i]) return true;
        }
        return false;
      }
      function getErrorMessageFromXhr(xhr) {
        var mime = xhr.getResponseHeader("Content-Type"), responseText = xhr.responseText, candidate;
        if (!mime) return null;
        if (mime.indexOf("text/plain") === 0) return responseText;
        if (mime.indexOf("application/json") === 0) {
          var jsonObj = safeParseJSON(responseText);
          if (typeof jsonObj === "string") return jsonObj;
          if (typeof jsonObj === "object") {
            for (var key in jsonObj) {
              if (typeof jsonObj[key] === "string") return jsonObj[key];
            }
          }
          return responseText;
        }
        if (mime.indexOf("application/problem+json") === 0) {
          var jsonObj = safeParseJSON(responseText);
          var candidate;
          if (typeof jsonObj === "object") {
            candidate = jsonObj.title;
            if (isNonEmptyString(candidate)) return candidate;
            candidate = jsonObj.detail;
            if (isNonEmptyString(candidate)) return candidate;
          }
          return responseText;
        }
        return null;
      }
      function safeParseJSON(json) {
        try {
          return JSON.parse(json);
        } catch (x) {
          return null;
        }
      }
      function isNonEmptyString(value) {
        return typeof value === "string" && value.length > 0;
      }
      return {
        createStore: function(options) {
          return new CustomStore(createStoreConfig(options));
        }
      };
    });
  }
});
export default require_devextreme_aspnet_data_nojquery();
//# sourceMappingURL=devextreme-aspnet-data-nojquery.js.map
